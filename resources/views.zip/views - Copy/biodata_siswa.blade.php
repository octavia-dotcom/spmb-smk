<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pendaftar — SMK Ma'arif Walisongo Kajoran</title>
<link rel="icon" type="image/png" href="{{ asset('img/logo.smk.png') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Sora:wght@600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ==========================================
           1. VARIABLE & RESET STYLING
        ========================================== */
        :root {
            --dark: #022c22;
            --accent: #047857;
            --accent-light: #ecfdf5;
            --bg: #f8f9fa;
            --card: #ffffff;
            --ink: #111827;
            --ink-soft: #6b7280;
            --line: #e5e7eb;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body {
            background: var(--bg);
            color: var(--ink);
            display: flex;
            overflow-x: hidden;
        }

        /* ==========================================
           2. SIDEBAR NAVIGASI
        ========================================== */
        .sidebar {
            width: 260px;
            background-color: var(--dark);
            color: #ffffff;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 20px 15px 15px 15px;
            z-index: 100;
            transition: all 0.3s ease;
        }
        .sidebar.collapsed {
            left: -260px;
        }
        .sidebar-header {
            display: flex;
            align-items: center;
            gap: 12px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            margin-bottom: 15px;
        }
        .logo-sekolah-img {
            width: 42px;
            height: 42px;
            object-fit: contain;
            border-radius: 4px;
        }
        .school-title h1 {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            line-height: 1.2;
            font-weight: 700;
        }
        .school-title h2 {
            font-size: 11px;
            color: #a0c4be;
            font-weight: 400;
        }
        .siswa-tag {
            display: inline-block;
            background-color: #0c5243;
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 4px;
            margin-top: 4px;
            color: #a7f3d0;
            font-weight: 600;
        }

        .menu-nav {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .menu-nav a {
            color: #ffffff;
            text-decoration: none;
            padding: 11px 14px;
            border-radius: 8px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background 0.2s;
        }
        .menu-nav a:hover, .menu-nav a.active {
            background-color: rgba(255, 255, 255, 0.15);
            font-weight: 600;
        }

        .help-card {
            background-color: rgba(255, 255, 255, 0.08);
            border-radius: 10px;
            padding: 12px;
            text-align: center;
            margin-bottom: 12px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .help-card h4 {
            font-size: 12px;
            margin-bottom: 2px;
        }
        .help-card p {
            font-size: 10px;
            color: #a0c4be;
            margin-bottom: 8px;
        }
        .btn-help {
            background: #ffffff;
            color: var(--dark);
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            width: 100%;
            transition: background 0.2s;
        }
        .btn-help:hover { background-color: #e6f4ea; }

        .sidebar-bottom {
            display: flex;
            flex-direction: column;
            gap: 10px;
            border-top: 1px solid rgba(255, 255, 255, 0.12);
            padding-top: 12px;
        }
        .btn-logout-sidebar {
            background-color: rgba(217, 83, 79, 0.2);
            color: #ffb3b3;
            border: 1px solid rgba(217, 83, 79, 0.3);
            padding: 9px;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 12px;
            font-weight: 600;
            width: 100%;
            transition: all 0.2s;
        }
        .btn-logout-sidebar:hover { background-color: #d9534f; color: #ffffff; }
        .sidebar-copyright {
            font-size: 10px;
            color: #a0c4be;
            text-align: center;
            line-height: 1.3;
        }

        /* ==========================================
           3. MAIN CONTENT AREA
        ========================================== */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
            transition: all 0.3s ease;
        }
        .main-content.expanded {
            margin-left: 0;
            width: 100%;
        }

        /* TOPBAR NAVBAR */
        .top-navbar {
            background-color: #ffffff;
            height: 65px;
            padding: 0 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--line);
            position: sticky;
            top: 0;
            z-index: 90;
        }
        .btn-toggle-menu {
            background: transparent;
            border: none;
            font-size: 18px;
            color: var(--dark);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 8px 10px;
            border-radius: 6px;
            transition: background 0.2s;
        }
        .btn-toggle-menu:hover { background-color: #f0f0f0; }
        .page-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--dark);
        }

        .profile-wrapper { position: relative; }
        .profile-btn {
            display: flex;
            align-items: center;
            gap: 12px;
            background: none;
            border: none;
            cursor: pointer;
            padding: 6px 10px;
            border-radius: 8px;
        }
        .profile-btn:hover { background-color: #f0f0f0; }
        .profile-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: var(--dark);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
        }
        .profile-text { text-align: right; line-height: 1.2; }
        .profile-text .name { font-weight: 700; font-size: 13px; color: #333; }
        .profile-text .nisn { font-size: 11px; color: #666; }

        .profile-dropdown {
            position: absolute;
            right: 0;
            top: 50px;
            background: #ffffff;
            border: 1px solid var(--line);
            border-radius: 8px;
            width: 170px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            display: none;
            flex-direction: column;
            overflow: hidden;
            z-index: 100;
        }
        .profile-dropdown.show { display: flex; }
        .dropdown-item {
            padding: 12px 16px;
            font-size: 13px;
            color: #333;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            border: none;
            background: none;
            width: 100%;
            text-align: left;
            cursor: pointer;
        }
        .dropdown-item:hover { background-color: #f5f5f5; }
        .dropdown-item.logout { color: #d9534f; border-top: 1px solid #eeeeee; }

        /* CONTENT BODY AREA */
        .content-body { padding: 30px; }

        .panel {
            background: var(--card);
            border-radius: 16px;
            padding: 30px;
            border: 1px solid var(--line);
            box-shadow: 0 2px 6px rgba(0,0,0,0.02);
        }
        .panel-head {
            display: flex;
            gap: 20px;
            align-items: center;
            margin-bottom: 24px;
        }
        .avatar-big {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            background: var(--accent-light);
            color: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            flex-shrink: 0;
            border: 2px solid #a7f3d0;
        }
        .panel-title { font-size: 20px; font-weight: 700; color: var(--dark); }
        .panel-sub { font-size: 13px; color: var(--ink-soft); }

        /* RINGKASAN STATUS ATAS */
        .stat-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
            background: #fafcfb;
            border: 1px solid var(--line);
            border-radius: 12px;
            padding: 16px 20px;
            margin-bottom: 26px;
        }
        .stat { display: flex; align-items: center; gap: 14px; }
        .stat-icon {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            background: var(--accent-light);
            color: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }
        .stat-label { font-size: 12px; color: var(--ink-soft); }
        .stat-value { font-size: 14px; font-weight: 700; color: var(--dark); }
        .badge {
            display: inline-block;
            font-size: 11px;
            font-weight: 700;
            padding: 3px 10px;
            border-radius: 20px;
            background: var(--accent-light);
            color: var(--accent);
            border: 1px solid #a7f3d0;
        }

        /* SECTION CARD BIODATA */
        .section {
            border: 1px solid var(--line);
            border-radius: 14px;
            padding: 22px;
            margin-bottom: 22px;
        }
        .section-head {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 18px;
        }
        .section-icon {
            width: 34px;
            height: 34px;
            border-radius: 8px;
            background: var(--accent-light);
            color: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
        }
        .section-title { font-size: 15px; font-weight: 700; color: var(--dark); }

        /* LAYOUT FIELD TABEL BIODATA & RESPONSIVE GRID */
        .grid-2 { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); 
            gap: 20px; 
        }
        .grid-3 { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); 
            gap: 20px; 
        }

        .field-list { display: flex; flex-direction: column; gap: 10px; }
        .field {
            display: grid;
            grid-template-columns: 140px 15px 1fr;
            font-size: 13px;
        }
        .field-label { font-weight: 600; color: var(--ink); }
        .field-sep { color: var(--ink-soft); }
        .field-val { 
            color: var(--ink-soft); 
            font-weight: 500;
            word-break: break-word;
        }

        /* KARTU ORANG TUA / WALI & JURUSAN */
        .subcard {
            background: #fafcfb;
            border: 1px solid var(--line);
            border-radius: 12px;
            padding: 16px 18px;
            min-width: 0;
        }
        .subcard-title {
            font-size: 12px;
            font-weight: 700;
            color: var(--accent);
            text-transform: uppercase;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .subcard-title::before {
            content: "";
            width: 6px;
            height: 6px;
            background: var(--accent);
            border-radius: 50%;
        }

        .jurusan-card {
            border: 1px solid var(--line);
            border-radius: 12px;
            padding: 18px;
            background: #fafcfb;
            min-width: 0;
        }
        .jurusan-eyebrow {
            font-size: 11px;
            font-weight: 700;
            color: var(--accent);
            text-transform: uppercase;
            margin-bottom: 6px;
        }
        .jurusan-code { font-size: 18px; font-weight: 800; color: var(--dark); }
        .jurusan-name { font-size: 12px; color: var(--ink-soft); margin-top: 2px; }

        .empty-note {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--ink-soft);
            font-size: 12px;
            background: #fafcfb;
            border: 1px dashed var(--line);
            border-radius: 12px;
            padding: 16px;
            min-width: 0;
        }

        /* TOMBOL ACTION BAWAH */
        .footer-actions {
            display: flex;
            justify-content: flex-end;
            margin-top: 10px;
        }
        .btn-edit {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--dark);
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 11px 22px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.2s;
        }
        .btn-edit:hover { background: var(--accent); }

        @media (max-width: 768px) {
            .main-content { margin-left: 0; width: 100%; }
            .content-body { padding: 15px; }
            .panel { padding: 20px; }
            .field { grid-template-columns: 120px 10px 1fr; }
        }
    </style>
</head>
<body>

    <div class="sidebar" id="sidebar">
        <div>
            <div class="sidebar-header">
                <img src="img/logo.smk.png" alt="Logo SMK" class="logo-sekolah-img" onerror="this.src='https://via.placeholder.com/42';">
                <div class="school-title">
                    <h1>SMK MAARIF WALISONGO KAJORAN</h1>
                    <h2>SPMB 2027/2028</h2>
                    <span class="siswa-tag">Siswa Panel</span>
                </div>
            </div>

            <div class="menu-nav">
                <a href="{{ url('/dashboard_siswa') }}"><i class="fa-solid fa-chart-pie"></i> Dashboard</a>
                <a href="{{ url('/biodata_siswa') }}" class="active"><i class="fa-solid fa-user-gear"></i> Profil Pendaftar</a>
                <a href="{{ url('/berkas_pendaftaran') }}"><i class="fa-solid fa-file-lines"></i> Berkas Pendaftaran</a>
                <a href="{{ url('/cetak_kartu') }}"><i class="fa-solid fa-address-card"></i> Cetak Kartu</a>
                <a href="{{ url('/pengumuman_siswa') }}"><i class="fa-solid fa-bullhorn"></i> Pengumuman</a>
            </div>
        </div>

        <div>
            <div class="help-card">
                <i class="fa-solid fa-headset" style="font-size: 18px; margin-bottom: 4px; color: #a7f3d0;"></i>
                <h4>Butuh bantuan?</h4>
                <p>Hubungi kami jika ada kendala pendaftaran</p>
                <button class="btn-help" onclick="hubungiAdminWA()">Hubungi kami &rarr;</button>
            </div>
            
            <div class="sidebar-bottom">
                <button class="btn-logout-sidebar" onclick="logoutSystem()">
                    <i class="fa-solid fa-right-from-bracket"></i> Logout
                </button>
                <div class="sidebar-copyright">
                    &copy; 2026 SMK Ma'arif Walisongo Kajoran<br>All Rights Reserved
                </div>
            </div>
        </div>
    </div>

    <div class="main-content" id="mainContent">

        <div class="top-navbar">
            <div style="display: flex; align-items: center; gap: 12px;">
                <button class="btn-toggle-menu" onclick="toggleSidebar()" title="Toggle Menu">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <div class="page-title">Profil Pendaftar</div>
            </div>

            <div class="profile-wrapper">
                <button class="profile-btn" onclick="toggleProfileDropdown(event)">
                    <div class="profile-text">
                        <div class="name" id="namaSiswaDisplay">{{ $pendaftar->nama_lengkap ?? 'Calon Siswa 1' }}</div>
                        <div class="nisn" id="nisnDisplay">NISN: {{ $pendaftar->nisn ?? '0081234567' }}</div>
                    </div>
                    <div class="profile-avatar"><i class="fa-solid fa-user"></i></div>
                    <i class="fa-solid fa-chevron-down" style="font-size: 11px; color: #888;"></i>
                </button>

                <div class="profile-dropdown" id="profileDropdown">
                    <button class="dropdown-item" onclick="window.location.href='{{ url('/biodata_siswa') }}'">
                        <i class="fa-solid fa-user"></i> Profil
                    </button>
                    <button class="dropdown-item logout" onclick="logoutSystem()">
                        <i class="fa-solid fa-right-from-bracket"></i> Logout
                    </button>
                </div>
            </div>
        </div>

        <div class="content-body">
            <div class="panel">

                <div class="panel-head">
                    <div class="avatar-big">
                        <i class="fa-solid fa-user-graduate"></i>
                    </div>
                    <div>
                        <h2 class="panel-title">Profil Pendaftar</h2>
                        <p class="panel-sub">Berikut ini adalah data lengkap biodata pendaftaran Anda.</p>
                    </div>
                </div>

                <div class="stat-row">
                    <div class="stat">
                        <div class="stat-icon"><i class="fa-solid fa-calendar-days"></i></div>
                        <div>
                            <div class="stat-label">Tanggal Daftar</div>
                            <div class="stat-value" id="val_tglDaftar">{{ $pendaftar->created_at->format('d M Y') }}</div>
                        </div>
                    </div>
                    <div class="stat">
                        <div class="stat-icon"><i class="fa-solid fa-id-card"></i></div>
                        <div>
                            <div class="stat-label">No. Pendaftaran</div>
                            <div class="stat-value" id="val_noPendaftaran">{{ $pendaftar->no_pendaftaran ?? 'SPMB-2027-000123' }}</div>
                        </div>
                    </div>
                    <div class="stat">
                        <div class="stat-icon"><i class="fa-solid fa-layer-group"></i></div>
                        <div>
                            <div class="stat-label">Gelombang</div>
                            <div class="stat-value" id="val_gelombang">{{ $pendaftar->gelombang ?? 'Gelombang 1' }}</div>
                        </div>
                    </div>
                    <div class="stat">
                        <div class="stat-icon"><i class="fa-solid fa-circle-check"></i></div>
                        <div>
                            <div class="stat-label">Status Pendaftaran</div>
                            <div class="stat-value"><span class="badge" id="val_status">{{ $pendaftar->status ?? 'Aktif' }}</span></div>
                        </div>
                    </div>
                </div>

                <!-- SECTION A: BIODATA SISWA -->
                <div class="section">
                    <div class="section-head">
                        <div class="section-icon"><i class="fa-solid fa-user"></i></div>
                        <h3 class="section-title">A. Biodata Siswa</h3>
                    </div>
                    <div class="grid-2">
                        <div class="field-list">
                            <div class="field"><span class="field-label">Nama Lengkap</span><span class="field-sep">:</span><span class="field-val" id="val_nama">{{ $pendaftar->nama_lengkap ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">NISN</span><span class="field-sep">:</span><span class="field-val" id="val_nisn">{{ $pendaftar->nisn ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Asal Sekolah</span><span class="field-sep">:</span><span class="field-val" id="val_sekolah">{{ $pendaftar->asal_sekolah ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Tempat Lahir</span><span class="field-sep">:</span><span class="field-val" id="val_tempatLahir">{{ $pendaftar->tempat_lahir ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Tanggal Lahir</span><span class="field-sep">:</span><span class="field-val" id="val_tglLahir">{{ $pendaftar->tanggal_lahir ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Jenis Kelamin</span><span class="field-sep">:</span><span class="field-val" id="val_jk">{{ $pendaftar->jenis_kelamin ?? '-' }}</span></div>
                        </div>
                        <div class="field-list">
                            <div class="field"><span class="field-label">Nomor HP Siswa</span><span class="field-sep">:</span><span class="field-val" id="val_hp">{{ $pendaftar->no_hp ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Ukuran Fisik</span><span class="field-sep">:</span><span class="field-val" id="val_fisik">{{ $pendaftar->tinggi_badan ?? '-' }} cm / {{ $pendaftar->berat_badan ?? '-' }} kg</span></div>
                            <div class="field"><span class="field-label">Jumlah Saudara</span><span class="field-sep">:</span><span class="field-val" id="val_saudara">{{ $pendaftar->jumlah_saudara ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Agama</span><span class="field-sep">:</span><span class="field-val" id="val_agama">{{ $pendaftar->agama ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Kebutuhan Khusus</span><span class="field-sep">:</span><span class="field-val" id="val_kebutuhanKhusus">{{ $pendaftar->kebutuhan_khusus ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Penerima KPS/KKS/KIP</span><span class="field-sep">:</span><span class="field-val" id="val_kpsKip">{{ $pendaftar->is_penerima_bantuan ?? '-' }}</span></div>
                        </div>
                    </div>
                </div>

                <!-- SECTION B: DATA ORANG TUA / WALI -->
                <div class="section">
                    <div class="section-head">
                        <div class="section-icon"><i class="fa-solid fa-users"></i></div>
                        <h3 class="section-title">B. Data Orang Tua / Wali</h3>
                    </div>
                    <div class="grid-3">
                        <!-- Card Ayah -->
                        <div class="subcard">
                            <div class="subcard-title">Data Ayah</div>
                            <div class="field-list">
                                <div class="field"><span class="field-label">Nama Ayah</span><span class="field-sep">:</span><span class="field-val" id="val_namaAyah">{{ $dataOrangTua->nama_ayah ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Pendidikan</span><span class="field-sep">:</span><span class="field-val" id="val_pendidikanAyah">{{ $dataOrangTua->pendidikan_ayah ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Pekerjaan</span><span class="field-sep">:</span><span class="field-val" id="val_pekerjaanAyah">{{ $dataOrangTua->pekerjaan_ayah ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Tahun Lahir</span><span class="field-sep">:</span><span class="field-val" id="val_tahunAyah">{{ $dataOrangTua->tahun_lahir_ayah ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Penghasilan</span><span class="field-sep">:</span><span class="field-val" id="val_penghasilanAyah">{{ $dataOrangTua->penghasilan_ayah ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">No. Telepon</span><span class="field-sep">:</span><span class="field-val" id="val_hpAyah">{{ $dataOrangTua->hp_ayah ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Kebutuhan Khusus</span><span class="field-sep">:</span><span class="field-val" id="val_khususAyah">{{ $dataOrangTua->khusus_ayah ?? '-' }}</span></div>
                            </div>
                        </div>
                        <!-- Card Ibu -->
                        <div class="subcard">
                            <div class="subcard-title">Data Ibu</div>
                            <div class="field-list">
                                <div class="field"><span class="field-label">Nama Ibu</span><span class="field-sep">:</span><span class="field-val" id="val_namaIbu">{{ $dataOrangTua->nama_ibu ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Pendidikan</span><span class="field-sep">:</span><span class="field-val" id="val_pendidikanIbu">{{ $dataOrangTua->pendidikan_ibu ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Pekerjaan</span><span class="field-sep">:</span><span class="field-val" id="val_pekerjaanIbu">{{ $dataOrangTua->pekerjaan_ibu ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Tahun Lahir</span><span class="field-sep">:</span><span class="field-val" id="val_tahunIbu">{{ $dataOrangTua->tahun_lahir_ibu ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Penghasilan</span><span class="field-sep">:</span><span class="field-val" id="val_penghasilanIbu">{{ $dataOrangTua->penghasilan_ibu ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">No. Telepon</span><span class="field-sep">:</span><span class="field-val" id="val_hpIbu">{{ $dataOrangTua->hp_ibu ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Kebutuhan Khusus</span><span class="field-sep">:</span><span class="field-val" id="val_khususIbu">{{ $dataOrangTua->khusus_ibu ?? '-' }}</span></div>
                            </div>
                        </div>
                        <!-- Card Wali -->
                        @if(isset($dataOrangTua) && $dataOrangTua->nama_wali)
                        <div class="subcard" id="boxWali">
                            <div class="subcard-title">Data Wali</div>
                            <div class="field-list">
                                <div class="field"><span class="field-label">Nama Wali</span><span class="field-sep">:</span><span class="field-val" id="val_namaWali">{{ $dataOrangTua->nama_wali }}</span></div>
                                <div class="field"><span class="field-label">Pendidikan</span><span class="field-sep">:</span><span class="field-val" id="val_pendidikanWali">{{ $dataOrangTua->pendidikan_wali ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Pekerjaan</span><span class="field-sep">:</span><span class="field-val" id="val_pekerjaanWali">{{ $dataOrangTua->pekerjaan_wali ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">Penghasilan</span><span class="field-sep">:</span><span class="field-val" id="val_penghasilanWali">{{ $dataOrangTua->penghasilan_wali ?? '-' }}</span></div>
                                <div class="field"><span class="field-label">No. Telepon</span><span class="field-sep">:</span><span class="field-val" id="val_hpWali">{{ $dataOrangTua->hp_wali ?? '-' }}</span></div>
                            </div>
                        </div>
                        @else
                        <div class="empty-note">
                            <i class="fa-solid fa-circle-info" style="font-size: 18px;"></i>
                            <span>Data wali tidak diisi (Opsional)</span>
                        </div>
                        @endif
                    </div>
                </div>

                <!-- SECTION C: DATA TEMPAT TINGGAL -->
                <div class="section">
                    <div class="section-head">
                        <div class="section-icon"><i class="fa-solid fa-house"></i></div>
                        <h3 class="section-title">C. Data Tempat Tinggal Siswa</h3>
                    </div>
                    <div class="grid-2">
                        <div class="field-list">
                            <div class="field"><span class="field-label">Provinsi</span><span class="field-sep">:</span><span class="field-val" id="val_provinsi">{{ $pendaftar->provinsi ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Kabupaten / Kota</span><span class="field-sep">:</span><span class="field-val" id="val_kabupaten">{{ $pendaftar->kabupaten ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Kecamatan</span><span class="field-sep">:</span><span class="field-val" id="val_kecamatan">{{ $pendaftar->kecamatan ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Desa / Kelurahan</span><span class="field-sep">:</span><span class="field-val" id="val_kelurahan">{{ $pendaftar->desa ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Kode Pos</span><span class="field-sep">:</span><span class="field-val" id="val_kodePos">{{ $pendaftar->kode_pos ?? '-' }}</span></div>
                        </div>
                        <div class="field-list">
                            <div class="field"><span class="field-label">Alamat Lengkap</span><span class="field-sep">:</span><span class="field-val" id="val_alamatLengkap">{{ $pendaftar->alamat ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">RT / RW</span><span class="field-sep">:</span><span class="field-val" id="val_rtRw">{{ $pendaftar->rt ?? '-' }} / {{ $pendaftar->rw ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Jenis Tinggal</span><span class="field-sep">:</span><span class="field-val" id="val_jenisTinggal">{{ $pendaftar->jenis_tinggal ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Alat Transportasi</span><span class="field-sep">:</span><span class="field-val" id="val_transportasi">{{ $pendaftar->transportasi ?? '-' }}</span></div>
                            <div class="field"><span class="field-label">Jarak ke Sekolah</span><span class="field-sep">:</span><span class="field-val" id="val_jarakSekolah">{{ $pendaftar->jarak_sekolah ?? '-' }}</span></div>
                        </div>
                    </div>
                </div>

                <!-- SECTION D: PILIHAN JURUSAN & GELOMBANG -->
                <div class="section">
                    <div class="section-head">
                        <div class="section-icon"><i class="fa-solid fa-graduation-cap"></i></div>
                        <h3 class="section-title">D. Pilihan Jurusan & Gelombang Pendaftaran</h3>
                    </div>
                    <div class="grid-2">
                        <div class="jurusan-card">
                            <div class="jurusan-eyebrow">Pilihan 1 (Utama)</div>
                            <div class="jurusan-code" id="val_j1Code">
                                {{ $pendaftar->jurusan_pilihan_1 ?? '-' }}
                            </div>
                            <div class="jurusan-name" id="val_j1Name">
                                {{ $pendaftar->jurusanPilihan1->nama_jurusan ?? '-' }}
                            </div>         
                        </div>
                        <div class="jurusan-card">
                            <div class="jurusan-eyebrow">Pilihan 2 (Kedua)</div>
                            <div class="jurusan-code" id="val_j2Code">
                                {{ $pendaftar->jurusan_pilihan_2 ?? '-' }}
                            </div>
                            <div class="jurusan-name" id="val_j2Name">
                                {{ $pendaftar->jurusanPilihan2->nama_jurusan ?? '-' }}
                            </div>
                        </div>
                    </div>
                    <div style="margin-top: 15px;" class="field-list">
                        <div class="field"><span class="field-label">Gelombang</span><span class="field-sep">:</span><span class="field-val" id="val_gelombangDetail">{{ $pendaftar->gelombang_detail ?? 'Gelombang 1 (Januari - Maret 2026)' }}</span></div>
                        <div class="field"><span class="field-label">Metode Pembayaran</span><span class="field-sep">:</span><span class="field-val" id="val_metodePembayaran">{{ $pendaftar->metode_pembayaran ?? 'Gratis / Bebas Biaya' }}</span></div>
                    </div>
                </div>

                <!-- SECTION E: DATA ASAL SEKOLAH -->
                <div class="section" style="margin-bottom: 0;">
                    <div class="section-head">
                        <div class="section-icon"><i class="fa-solid fa-school"></i></div>
                        <h3 class="section-title">E. Data Asal Sekolah</h3>
                    </div>
                    <div class="field-list">
                        <div class="field"><span class="field-label">Asal Sekolah</span><span class="field-sep">:</span><span class="field-val" id="val_asalSekolah">{{ $pendaftar->asal_sekolah ?? '-' }}</span></div>
                    </div>
                </div>

                <div class="footer-actions">
                    <a href="{{ url('/edit_data_siswa') }}" class="btn-edit">
                        <i class="fa-solid fa-pen-to-square"></i> Edit Data
                    </a>
                </div> 

            </div>
        </div>
    </div>

    <script>
        // Mapping Nama Jurusan Lengkap berdasarkan Kode
        const mapJurusan = {
            'PPLG': 'Pengembangan Perangkat Lunak dan Gim',
            'BCF': 'Broadcasting dan Perfilman',
            'TO': 'Teknik Otomotif',
            'AKL': 'Akuntansi dan Keuangan Lembaga',
            'TJKT': 'Teknik Jaringan Komputer dan Telekomunikasi'
        };

        // Fungsi Memuat Data dari LocalStorage
        function loadBiodataSiswa() {
            const dataPendaftaran = localStorage.getItem('data_pendaftaran');
            if (!dataPendaftaran) return;

            try {
                const data = JSON.parse(dataPendaftaran);

                const setText = (id, val) => {
                    const el = document.getElementById(id);
                    if (el && val !== undefined && val !== null && val !== "") {
                        el.innerText = val;
                    }
                };

                setText('namaSiswaDisplay', data.namaLengkap || data.nama);
                setText('nisnDisplay', data.nisn ? `NISN: ${data.nisn}` : null);

                setText('val_tglDaftar', data.tglDaftar || data.tanggalDaftar);
                setText('val_noPendaftaran', data.noPendaftaran || data.nomorPendaftaran);
                setText('val_gelombang', data.gelombang);
                setText('val_status', data.status);

                setText('val_nama', data.namaLengkap || data.nama);
                setText('val_nisn', data.nisn);
                setText('val_sekolah', data.asalSekolah || data.sekolah);
                setText('val_tempatLahir', data.tempatLahir);
                setText('val_tglLahir', data.tglLahir || data.tanggalLahir);
                setText('val_jk', data.jk || data.jenisKelamin);
                setText('val_hp', data.hp || data.nomorHp || data.telepon);
                setText('val_saudara', data.saudara || data.jumlahSaudara);
                setText('val_agama', data.agama);
                setText('val_kebutuhanKhusus', data.kebutuhanKhusus);
                setText('val_kpsKip', data.kpsKip || data.kip);

                if (data.tinggiBadan && data.beratBadan) {
                    setText('val_fisik', `${data.tinggiBadan} cm / ${data.beratBadan} kg`);
                } else {
                    setText('val_fisik', data.fisik);
                }

                setText('val_namaAyah', data.namaAyah);
                setText('val_pendidikanAyah', data.pendidikanAyah);
                setText('val_pekerjaanAyah', data.pekerjaanAyah);
                setText('val_tahunAyah', data.tahunAyah);
                setText('val_penghasilanAyah', data.penghasilanAyah);
                setText('val_hpAyah', data.hpAyah);
                setText('val_khususAyah', data.khususAyah);

                setText('val_namaIbu', data.namaIbu);
                setText('val_pendidikanIbu', data.pendidikanIbu);
                setText('val_pekerjaanIbu', data.pekerjaanIbu);
                setText('val_tahunIbu', data.tahunIbu);
                setText('val_penghasilanIbu', data.penghasilanIbu);
                setText('val_hpIbu', data.hpIbu);
                setText('val_khususIbu', data.khususIbu);

                setText('val_namaWali', data.namaWali || "-");
                setText('val_pendidikanWali', data.pendidikanWali || "-");
                setText('val_pekerjaanWali', data.pekerjaanWali || "-");
                setText('val_penghasilanWali', data.penghasilanWali || "-");
                setText('val_hpWali', data.hpWali || "-");

                setText('val_provinsi', data.provinsi);
                setText('val_kabupaten', data.kabupaten);
                setText('val_kecamatan', data.kecamatan);
                setText('val_kelurahan', data.kelurahan || data.desa);
                setText('val_kodePos', data.kodePos);
                setText('val_alamatLengkap', data.alamatLengkap || data.alamat);
                setText('val_rtRw', data.rtRw || (data.rt && data.rw ? `RT ${data.rt} / RW ${data.rw}` : null));
                setText('val_jenisTinggal', data.jenisTinggal);
                setText('val_transportasi', data.transportasi);
                setText('val_jarakSekolah', data.jarakSekolah);

                const j1 = data.jurusan1 || data.pilihan1;
                const j2 = data.jurusan2 || data.pilihan2;

                if (j1) {
                    setText('val_j1Code', j1);
                    setText('val_j1Name', mapJurusan[j1] || j1);
                }
                if (j2) {
                    setText('val_j2Code', j2);
                    setText('val_j2Name', mapJurusan[j2] || j2);
                }

                setText('val_gelombangDetail', data.gelombangDetail || data.gelombang);
                setText('val_metodePembayaran', data.metodePembayaran);

                setText('val_asalSekolah', data.asalSekolah || data.sekolah);

            } catch (err) {
                console.error("Gagal membaca data dari localStorage:", err);
            }
        }

        document.addEventListener('DOMContentLoaded', loadBiodataSiswa);

        function hubungiAdminWA() {
            const elemNama = document.getElementById('namaSiswaDisplay');
            const namaSiswa = elemNama ? elemNama.innerText.trim() : "Calon Siswa";
            const noAdmin = "622933195678";
            const teksPesan = `Halo Admin SPMB SMK Ma'arif Walisongo Kajoran, nama saya *${namaSiswa}*. Saya mau bertanya/mengajukan kendala terkait pendaftaran online. Mohon bantuannya, terima kasih!`;
            const urlWA = `https://wa.me/${noAdmin}?text=${encodeURIComponent(teksPesan)}`;
            window.open(urlWA, '_blank');
        }

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
        }

        function toggleProfileDropdown(event) {
            event.stopPropagation();
            document.getElementById('profileDropdown').classList.toggle('show');
        }

        window.addEventListener('click', function() {
            const dropdown = document.getElementById('profileDropdown');
            if (dropdown && dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            }
        });

        function logoutSystem() {
            if (confirm("Apakah Anda yakin ingin keluar dari sistem?")) {
                window.location.href = "{{ url('/login') }}";
            }
        }
    </script>
</body>
</html>