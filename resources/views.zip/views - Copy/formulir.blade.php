<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Isi Formulir Pendaftaran - SMK Ma'arif Walisongo Kajoran</title>
<link rel="icon" type="image/png" href="{{ asset('img/logo.smk.png') }}">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ==========================================================================
           1. RESET & GLOBAL STYLES
           ========================================================================== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #02403f;
            color: #1e293b;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            gap: 50px;
            padding: 5px 5px 40px 5px;
        }
        .register-container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 30px;
            padding: 40px 50px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            height: auto;
        }

        /* ==========================================================================
           2. NAVBAR ATAS (KAPSUL PUTIH)
           ========================================================================== */
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            position: sticky;
            top: 20px;
            z-index: 1000;
            width: 94%;
            margin: 20px auto 0 auto;
            border-radius: 15px;
            padding: 5px 25px;
        }
        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 15px;
        }
        .logo-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .logo-sekolah { height: 45px; width: auto; }
        .logo-smkhebat { height: 45px; width: auto; }
        .logo-vokasi { height: 45px; width: auto; }
        .logo-akreditasi-nav { height: 45px; width: auto; }

        .nav-menu { display: flex; align-items: center; }
        .nav-menu a {
            text-decoration: none;
            color: #475569;
            margin: 0 15px;
            font-weight: 600;
            font-size: 15px;
            transition: color 0.3s;
        }
        .nav-menu a:hover, .nav-menu a.active { color: #047857; }

        .btn-cta {
            background-color: #064e3b;
            color: white;
            text-decoration: none;
            padding: 10px 35px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 15px;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
        }
        .btn-cta:hover { background-color: #047857; }

        /* ==========================================================================
           3. HEADER & STEPPER PROGRESS
           ========================================================================== */
        .register-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px dashed #e2e8f0;
            padding-bottom: 25px;
            margin-bottom: 30px;
        }
        .header-title-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .icon-add-user {
            width: 45px;
            height: 45px;
            background-color: #e6f4f0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .icon-add-user img {
            width: 50px;
            height: 50px;
            object-fit: contain;
        }
        .header-text h1 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 18px;
            font-weight: 800;
            color: #02403f;
        }
        .header-text p {
            font-size: 12px;
            color: #64748b;
        }

        .stepper-groups {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .step-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .step-number {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 700;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .step-item.completed .step-number {
            background-color: #e6f4f0;
            color: #02403f;
            border: 1px solid #02403f;
        }
        .step-item.active .step-number {
            background-color: #02403f;
            color: #ffffff;
        }
        .step-item.inactive .step-number {
            border: 1px solid #cbd5e1;
            color: #94a3b8;
            background: #ffffff;
        }
        .step-text {
            font-size: 11px;
            font-weight: 600;
            color: #475569;
        }
        .step-item.inactive .step-text {
            color: #94a3b8;
        }
        .step-line {
            width: 30px;
            height: 1px;
            background-color: #cbd5e1;
        }

        /* ==========================================================================
           4. FORM LAYOUT & INPUT STYLES
           ========================================================================== */
        .form-section-title {
            font-size: 14px;
            font-weight: 700;
            color: #007a53;
            margin-bottom: 25px;
            position: relative;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 24px 30px;
            margin-bottom: 35px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .form-row-split {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        
        .form-group label {
            font-size: 12px;
            font-weight: 600;
            color: #344054;
        }
        .form-group label span {
            color: #d92d20;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 14px;
            background: #ffffff;
            border: 1px solid #d0d5dd;
            border-radius: 8px;
            font-size: 13px;
            color: #1e293b;
            font-family: inherit;
            outline: none;
            transition: all 0.2s;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: #02403f;
            box-shadow: 0 0 0 4px rgba(2, 64, 63, 0.1);
        }
        
        .radio-group-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px 20px;
            background-color: #f8fafc;
            padding: 10px 14px;
            border: 1px solid #d0d5dd;
            border-radius: 8px;
            min-height: 41px;
            align-items: center;
        }
        
        .checkbox-group-container {
            display: flex;
            flex-direction: column;
            gap: 12px;
            background-color: #f8fafc;
            padding: 15px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            margin-top: 5px;
        }
        .selection-option {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            color: #344054;
        }
        .selection-option input {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #02403f;
        }

        .conditional-box {
            display: none; 
            grid-column: span 2;
            animation: fadeIn 0.3s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-5px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .parent-subtitle-only {
            display: block;
            grid-column: span 2;
            font-size: 13px;
            font-weight: 400;
            color: #64748b;
            margin-top: -18px;
            margin-bottom: 15px;
            text-transform: none;
        }
        .divider-data-ibu {
            grid-column: span 2;
            margin-top: 30px;
            margin-bottom: 10px;
            font-weight: 700;
            font-size: 14px;
            color: #007a53;
            border-top: 1px dashed #cbd5e1;
            padding-top: 20px;
        }

        /* ==========================================================================
           5. ACTION BUTTONS
           ========================================================================== */
        .action-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 50px;
            border-top: 1px dashed #e2e8f0;
            padding-top: 25px;
        }
        .btn-back {
            border: 1px solid #02403f;
            background: transparent;
            color: #02403f;
            padding: 10px 25px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background 0.2s;
        }
        .btn-back:hover {
            background-color: #f0f7f4;
        }
        .btn-next {
            background-color: #02403f;
            border: none;
            color: #ffffff;
            padding: 11px 50px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none !important;
            transition: background 0.2s;
        }
        .btn-next:hover {
            background-color: #012b2a;
        }
        @media (max-width: 768px) {
           .form-group-row {
                flex-direction: column;
           }
        }
        @media (max-width: 480px) {
            .navbar{
                flex-direction: column;
            }
            .input-field {
                width: 100%;
            }
        }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="nav-container">
            <div class="logo-group">
                <img id="navLogoSekolah" src="img/logo.smk.png" alt="Logo SMK Ma'arif" class="logo-sekolah">
                <img id="navLogoSmkHebat" src="img/logo-smk-hebat.png" alt="Logo SMK Bisa Hebat" class="logo-smkhebat">
                <img id="navLogoVokasi" src="img/logo-smk-vokasi.png" alt="Logo SMK Vokasi" class="logo-vokasi">
                <img id="navLogoAkreditasi" src="img/akreditasi.png" alt="Akreditasi A" class="logo-akreditasi-nav">
            </div>
            <nav class="nav-menu">
                <a href="{{ url('/home') }}">Beranda</a>
                <a href="{{ url('/formulir') }}" class="active">Pendaftaran</a>
                <a href="{{ url('/jurusan') }}">Jurusan</a>
                <a href="{{ url('/informasi') }}">Informasi</a>
                <a href="{{ url('/kontak') }}">Kontak</a>
            </nav>
            <a href="{{ url('/login') }}" class="btn-cta">Log in</a>
        </div>
    </header>

    <div class="register-container">
        <header class="register-header">
            <div class="header-title-group">
                <div class="icon-add-user">
                    <img src="img/isifor.png" alt="daftar akun">
                </div>
                <div class="header-text">
                    <h1 id="formulirJudul">Pengisian Formulir</h1>
                    <p id="formulirDesc">Silakan lengkapi data calon peserta didik baru dengan benar</p>
                </div>
            </div>
            <div class="stepper-groups">
                <a href="{{ url('/daftar') }}" style="text-decoration: none;">
                    <div class="step-item completed">
                        <div class="step-number">1</div>
                        <span class="step-text">Buat Akun</span>
                    </div>
                </a>
                <div class="step-line"></div>
                <a href="{{ url('/formulir') }}" style="text-decoration: none;">
                    <div class="step-item active">
                        <div class="step-number">2</div>
                        <span class="step-text">Isi Formulir</span>
                    </div>
                </a>
                <div class="step-line"></div>
                <a href="{{ url('/unggah_berkas') }}" style="text-decoration: none;">
                    <div class="step-item inactive">
                        <div class="step-number">3</div>
                        <span class="step-text">Unggah Berkas</span>
                    </div>
                </a>
            </div>
        </header>

        <main>
            @if ($errors->any())
            <div style="background: #ffe6e6; color: #d8000c; padding: 10px; margin-bottom: 15px; border-radius: 5px;">
                <strong>Perhatian! Ada data yang belum lengkap:</strong>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif

            <form id="formPendaftaran" action="{{ url('/daftar') }}" method="POST">
                @csrf
                
                <div class="form-section-title">Data Lengkap Calon Siswa</div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Nama Lengkap Calon Siswa<span>*</span></label>
                        <input type="text" id="input_nama_lengkap_calon_siswa" name="nama_lengkap" value="{{ old('nama_lengkap') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Asal Sekolah<span>*</span></label>
                        <input type="text" id="input_asal_sekolah" name="asal_sekolah" value="{{ old('asal_sekolah') }}" required>
                    </div>

                    <div class="form-group">
                        <label>NISN <span>*</span></label>
                        <input type="number" id="input_NISN" name="nisn" value="{{ old('nisn') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Nomor Hp Siswa (aktif)<span>*</span></label>
                        <input type="number" id="input_nomor_hp_siswa" name="no_hp" value="{{ old('no_hp') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Tempat Lahir<span>*</span></label>
                        <input type="text" id="input_tempat_lahir" name="tempat_lahir" value="{{ old('tempat_lahir') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Ukuran Fisik (Tinggi & Berat) <span>*</span></label>
                        <div class="form-row-split">
                            <input type="number" id="input_tinggi" name="tinggi_badan" value="{{ old('tinggi_badan') }}" placeholder="Tinggi (cm)" required>
                            <input type="number" id="input_berat" name="berat_badan" value="{{ old('berat_badan') }}" placeholder="Berat (kg)" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Tanggal Lahir<span>*</span></label>
                        <input type="date" id="input_tanggal_lahir" name="tanggal_lahir" value="{{ old('tanggal_lahir') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Jumlah Saudara<span>*</span></label>
                        <input type="number" id="input_jumlah_saudara" name="jumlah_saudara_kandung" value="{{ old('jumlah_saudara_kandung') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Jenis Kelamin <span>*</span></label>
                        <div class="radio-group-container">
                            <label class="selection-option">
                                <input type="radio" name="jenis_kelamin" value="L" {{ old('jenis_kelamin') == 'L' ? 'checked' : '' }} required> Laki-laki
                            </label>
                            <label class="selection-option">
                                <input type="radio" name="jenis_kelamin" value="P" {{ old('jenis_kelamin') == 'P' ? 'checked' : '' }} required> Perempuan
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Memiliki Kebutuhan Khusus? <span>*</span></label>
                        <div class="radio-group-container">
                            <label class="selection-option">
                                <input type="radio" name="kebutuhan_khusus" value="ya" {{ old('kebutuhan_khusus') == 'ya' ? 'checked' : '' }} required> Ya
                            </label>
                            <label class="selection-option">
                                <input type="radio" name="kebutuhan_khusus" value="tidak" {{ old('kebutuhan_khusus') == 'tidak' ? 'checked' : '' }} required> Tidak
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Agama<span>*</span></label>
                        <input type="text" id="input_agama" name="agama" value="{{ old('agama') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Penerima KPS / KKS / KIP? <span>*</span></label>
                        <div class="radio-group-container">
                            <label class="selection-option">
                                <input type="radio" name="is_penerima_bantuan" value="ya" onclick="toggleKphCard(true)" {{ old('penerima_kps') == 'ya' ? 'checked' : '' }} required> Ya
                            </label>
                            <label class="selection-option">
                                <input type="radio" name="is_penerima_bantuan" value="tidak" onclick="toggleKphCard(false)" {{ old('penerima_kps') == 'tidak' ? 'checked' : '' }} required> Tidak
                            </label>
                        </div>
                    </div>

                    <div class="form-group conditional-box" id="kph-card-selection">
                        <label>Pilih Jenis Kartu yang Dimiliki <span>*</span></label>
                        <div class="checkbox-group-container">
                            <label class="selection-option">
                                <input type="checkbox" name="jenis_bantuan" value="KPS"> KPS (Kartu Perlindungan Sosial)
                            </label>
                            <label class="selection-option">
                                <input type="checkbox" name="jenis_bantuan" value="KKS"> KKS (Kartu Keluarga Sejahtera)
                            </label>
                            <label class="selection-option">
                                <input type="checkbox" name="jenis_bantuan" value="KIP"> KIP (Kartu Indonesia Pintar)
                            </label>
                        </div>
                    </div>

                    <div class="form-section-title" style="grid-column: span 2; margin-top: 25px; margin-bottom: 5px;">Data Orang Tua</div>
                    <span class="parent-subtitle-only">Data Ayah*</span>

                    <div class="form-group">
                        <label>Nama Ayah</label>
                        <input type="text" id="input_nama_ayah" name="nama_ayah" value="{{ old('nama_ayah') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Pendidikan Terakhir</label>
                        <select id="pendidikan_ayah" name="pendidikan_terakhir_ayah" class="form-control" required>
                            <option value="" disabled selected>Pilih Pendidikan Terakhir</option>
                            <option value="tidak_sekolah" {{ old('pendidikan_terakhir_ayah') == 'tidak_sekolah' ? 'selected' : '' }}>Tidak Sekolah</option>
                            <option value="sd" {{ old('pendidikan_terakhir_ayah') == 'sd' ? 'selected' : '' }}>SD / MI / Sederajat</option> 
                            <option value="smp" {{ old('pendidikan_terakhir_ayah') == 'smp' ? 'selected' : '' }}>SMP / Mts / Sederajat</option>
                            <option value="sma" {{ old('pendidikan_terakhir_ayah') == 'sma' ? 'selected' : '' }}>SMA / MA / SMK</option>
                            <option value="diploma" {{ old('pendidikan_terakhir_ayah') == 'diploma' ? 'selected' : '' }}>D1 / D2/ D3</option>
                            <option value="s1" {{ old('pendidikan_terakhir_ayah') == 's1' ? 'selected' : '' }}>S2 (Magister)</option>
                            <option value="s2" {{ old('pendidikan_terakhir_ayah') == 's2' ? 'selected' : '' }}>S3 (Doktor)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Pekerjaan Ayah</label>
                        <input type="text" id="input_pekerjaan_ayah" name="pekerjaan_ayah" value="{{ old('pekerjaan_ayah') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Tahun Lahir</label>
                        <input type="text" id="input_tahun_lahir_ayah" name="tahun_lahir_ayah" value="{{ old('tahun_lahir_ayah') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Penghasilan Bulanan</label>
                        <select id="penghasilan_ayah_select" name="penghasilan_bulanan_ayah" class="form-control" required>
                            <option value="" disabled selected>Pilih Penghasilan Bulanan</option>
                            <option value="tidak_berpenghasilan" {{ old('penghasilan_bulanan_ayah') == 'tidak_berpenghasilan' ? 'selected' : '' }}>Tidak Berpenghasilan / Tidak Bekerja</option>
                            <option value="kurang_1jt" {{ old('penghasilan_bulanan_ayah') == 'kurang_1jt' ? 'selected' : '' }}>Kurang dari Rp 1.000.000</option>
                            <option value="1jt_2jt" {{ old('penghasilan_bulanan_ayah') == '1jt_2jt' ? 'selected' : '' }}>Rp 1.000.000 - Rp 1.999.999</option>
                            <option value="2jt_5jt" {{ old('penghasilan_bulanan_ayah') == '2jt_5jt' ? 'selected' : '' }}>Rp 2.000.000 - Rp 4.999.999</option>
                            <option value="5jt_20jt" {{ old('penghasilan_bulanan_ayah') == '5jt_20jt' ? 'selected' : '' }}>Rp 5.000.000 - Rp 20.000.000</option>
                            <option value="lebih_20jt" {{ old('penghasilan_bulanan_ayah') == 'lebih_20jt' ? 'selected' : '' }}>Lebih dari Rp 20.000.000</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Nomor Telepon Ayah</label>
                        <input type="text" id="input_nomor_telepon_ayah" name="nomor_telepon_ayah" value="{{ old('nomor_telepon_ayah') }}" required>
                    </div>

                    <div class="form-group">
                <label>Memiliki Kebutuhan Khusus?</label>
                <div class="radio-group-container">
                    <label class="selection-option">
                        <input type="radio" name="ayah_kebutuhan_khusus" value="Ya" {{ old('ayah_kebutuhan_khusus') == 'Ya' ? 'checked' : '' }} required> Ya
                    </label>
                    <label class="selection-option">
                        <input type="radio" name="ayah_kebutuhan_khusus" value="Tidak" {{ old('ayah_kebutuhan_khusus') == 'Tidak' ? 'checked' : '' }} required> Tidak
                    </label>
                </div>
            </div> 
                    <div class="divider-data-ibu">Data Ibu*</div>

                    <div class="form-group">
                        <label>Nama Ibu</label>
                        <input type="text" id="input_nama_ibu" name="nama_ibu" value="{{ old('nama_ibu') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Pendidikan Terakhir</label>
                        <select id="pendidikan_ibu" name="pendidikan_terakhir_ibu" class="form-control" required>
                            <option value="" disabled selected>Pilih Pendidikan Terakhir</option>
                            <option value="tidak_sekolah" {{ old('pendidikan_terakhir_ibu') == 'tidak_sekolah' ? 'selected' : '' }}>Tidak Sekolah</option>
                            <option value="sd" {{ old('pendidikan_terakhir_ibu') == 'sd' ? 'selected' : '' }}>SD / MI / Sederajat</option> 
                            <option value="smp" {{ old('pendidikan_terakhir_ibu') == 'smp' ? 'selected' : '' }}>SMP / Mts / Sederajat</option>
                            <option value="sma" {{ old('pendidikan_terakhir_ibu') == 'sma' ? 'selected' : '' }}>SMA / MA / SMK</option>
                            <option value="diploma" {{ old('pendidikan_terakhir_ibu') == 'diploma' ? 'selected' : '' }}>D1 / D2/ D3</option>
                            <option value="s1" {{ old('pendidikan_terakhir_ibu') == 's1' ? 'selected' : '' }}>S2 (Magister)</option>
                            <option value="s2" {{ old('pendidikan_terakhir_ibu') == 's2' ? 'selected' : '' }}>S3 (Doktor)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Pekerjaan Ibu</label>
                        <input type="text" id="input_pekerjaan_ibu" name="pekerjaan_ibu" value="{{ old('pekerjaan_ibu') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Tahun Lahir</label>
                        <input type="text" id="input_tahun_lahir_ibu" name="tahun_lahir_ibu" value="{{ old('tahun_lahir_ibu') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Penghasilan Bulanan</label>
                        <select id="penghasilan_ibu_select" name="penghasilan_bulanan_ibu" class="form-control" required>
                            <option value="" disabled selected>Pilih Penghasilan Bulanan</option>
                            <option value="tidak_berpenghasilan" {{ old('penghasilan_bulanan_ibu') == 'tidak_berpenghasilan' ? 'selected' : '' }}>Tidak Berpenghasilan / Tidak Bekerja</option>
                            <option value="kurang_1jt" {{ old('penghasilan_bulanan_ibu') == 'kurang_1jt' ? 'selected' : '' }}>Kurang dari Rp 1.000.000</option>
                            <option value="1jt_2jt" {{ old('penghasilan_bulanan_ibu') == '1jt_2jt' ? 'selected' : '' }}>Rp 1.000.000 - Rp 1.999.999</option>
                            <option value="2jt_5jt" {{ old('penghasilan_bulanan_ibu') == '2jt_5jt' ? 'selected' : '' }}>Rp 2.000.000 - Rp 4.999.999</option>
                            <option value="5jt_20jt" {{ old('penghasilan_bulanan_ibu') == '5jt_20jt' ? 'selected' : '' }}>Rp 5.000.000 - Rp 20.000.000</option>
                            <option value="lebih_20jt" {{ old('penghasilan_bulanan_ibu') == 'lebih_20jt' ? 'selected' : '' }}>Lebih dari Rp 20.000.000</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Nomor Telepon Ibu</label>
                        <input type="text" id="input_nomor_telepon_ibu" name="nomor_hp_ibu" value="{{ old('nomor_hp_ibu') }}" required>
                    </div>

                   <div class="form-group">
            <label>Memiliki Kebutuhan Khusus? </label>
                <div class="radio-group-container">
                    <label class="selection-option">
                        <input type="radio" name="ibu_kebutuhan_khusus" value="Ya" {{ old('ibu_kebutuhan_khusus') == 'Ya' ? 'checked' : '' }} required> Ya
                    </label>
                    <label class="selection-option">
                        <input type="radio" name="ibu_kebutuhan_khusus" value="Tidak" {{ old('ibu_kebutuhan_khusus') == 'Tidak' ? 'checked' : '' }} required> Tidak
                    </label>
                </div>
            </div> 

                    <div class="divider-data-ibu" style="margin-top: 25px;">Data Wali (Diisi jika tidak tinggal dengan Orang Tua)</div>

                    <div class="form-group">
                        <label>Nama Wali</label>
                        <input type="text" id="input_nama_wali" name="nama_wali" value="{{ old('nama_wali') }}">
                    </div>

                    <div class="form-group">
                        <label>Pendidikan Terakhir Wali</label>
                        <select id="pendidikan_wali" name="pendidikan_terakhir_wali" class="form-control"> 
                            <option value="" disabled selected>Pilih Pendidikan Terakhir</option>
                            <option value="tidak_sekolah" {{ old('pendidikan_terakhir_wali') == 'tidak_sekolah' ? 'selected' : '' }}>Tidak Sekolah</option>
                            <option value="sd" {{ old('pendidikan_terakhir_wali') == 'sd' ? 'selected' : '' }}>SD / MI / Sederajat</option> 
                            <option value="smp" {{ old('pendidikan_terakhir_wali') == 'smp' ? 'selected' : '' }}>SMP / Mts / Sederajat</option>
                            <option value="sma" {{ old('pendidikan_terakhir_wali') == 'sma' ? 'selected' : '' }}>SMA / MA / SMK</option>
                            <option value="diploma" {{ old('pendidikan_terakhir_wali') == 'diploma' ? 'selected' : '' }}>D1 / D2/ D3</option>
                            <option value="s1" {{ old('pendidikan_terakhir_wali') == 's1' ? 'selected' : '' }}>S2 (Magister)</option>
                            <option value="s2" {{ old('pendidikan_terakhir_wali') == 's2' ? 'selected' : '' }}>S3 (Doktor)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Pekerjaan Wali</label>
                        <input type="text" id="input_pekerjaan_wali" name="pekerjaan_wali" value="{{ old('pekerjaan_wali') }}">
                    </div>

                    <div class="form-group">
                        <label>Penghasilan Bulanan</label>
                        <select id="penghasilan_wali_select" name="penghasilan_bulanan_wali" class="form-control">
                            <option value="" disabled selected>Pilih Penghasilan Bulanan</option>
                            <option value="tidak_berpenghasilan" {{ old('penghasilan_bulanan_wali') == 'tidak_berpenghasilan' ? 'selected' : '' }}>Tidak Berpenghasilan / Tidak Bekerja</option>
                            <option value="kurang_1jt" {{ old('penghasilan_bulanan_wali') == 'kurang_1jt' ? 'selected' : '' }}>Kurang dari Rp 1.000.000</option>
                            <option value="1jt_2jt" {{ old('penghasilan_bulanan_wali') == '1jt_2jt' ? 'selected' : '' }}>Rp 1.000.000 - Rp 1.999.999</option>
                            <option value="2jt_5jt" {{ old('penghasilan_bulanan_wali') == '2jt_5jt' ? 'selected' : '' }}>Rp 2.000.000 - Rp 4.999.999</option>
                            <option value="5jt_20jt" {{ old('penghasilan_bulanan_wali') == '5jt_20jt' ? 'selected' : '' }}>Rp 5.000.000 - Rp 20.000.000</option>
                            <option value="lebih_20jt" {{ old('penghasilan_bulanan_wali') == 'lebih_20jt' ? 'selected' : '' }}>Lebih dari Rp 20.000.000</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Nomor Telepon Wali</label>
                        <input type="text" id="input_nomor_telepon_wali" name="nomor_hp_wali" value="{{ old('nomor_hp_wali') }}">
                    </div>

                    <div class="form-section-title" style="grid-column: span 2; margin-top: 25px;">Data Tempat Tinggal Siswa</div>
                    
                    <div class="form-group">
                        <label>Provinsi<span>*</span></label>
                        <select id="provinsi" name="provinsi" class="form-control" required>
                            <option value="">Pilih Provinsi</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Alamat Lengkap<span>*</span></label>
                        <input type="text" id="input_alamat_lengkap" name="alamat_lengkap" value="{{ old('alamat_lengkap') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Kabupaten / Kota<span>*</span></label>
                        <select id="kabupaten" name="kabupaten" class="form-control" required disabled>
                            <option value="">Pilih Kabupaten</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>RT / RW <span>*</span></label>
                        <div class="form-row-split">
                            <input type="number" id="input_rt" name="rt" value="{{ old('rt') }}" placeholder="RT" required>
                            <input type="number" id="input_rw" name="rw" value="{{ old('rw') }}" placeholder="RW" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Kecamatan<span>*</span></label>
                        <select id="kecamatan" name="kecamatan" class="form-control" required disabled>
                            <option value="">Pilih Kecamatan</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="jenis_tinggal">Jenis Tinggal<span>*</span></label>
                        <select id="jenis_tinggal" name="jenis_tinggal" class="form-control" required>
                            <option value="" disabled selected>Pilih Jenis Tinggal</option>
                            <option value="Bersama Orang Tua" {{ old('jenis_tinggal') == 'Bersama Orang Tua' ? 'selected' : '' }}>Rumah (Bersama Orang Tua)</option>
                            <option value="Wali" {{ old('jenis_tinggal') == 'Wali' ? 'selected' : '' }}>Asrama</option>
                            <option value="Kos" {{ old('jenis_tinggal') == 'Kos' ? 'selected' : '' }}>Kos / Kontrak</option>
                            <option value="Pondok" {{ old('jenis_tinggal') == 'Pondok' ? 'selected' : '' }}>Pondok Pesantren</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Desa/Kelurahan<span>*</span></label>
                        <select id="kelurahan" name="desa" class="form-control" required disabled>
                            <option value="">Pilih Kelurahan/Desa</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Alat Transportasi <span>*</span></label>
                        <input type="text" id="input_alat_transportasi" name="alat_transportasi_ke_sekolah" value="{{ old('alat_transportasi_ke_sekolah') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Kode Pos <span>*</span></label>
                        <input type="number" id="input_kode_pos" name="kode_pos" value="{{ old('kode_pos') }}" required>
                    </div>

                    <div class="form-group">
                        <label>Jarak ke Sekolah<span>*</span></label>
                        <input type="text" id="input_jarak_kesekolah" name="jarak_ke_sekolah" value="{{ old('jarak_ke_sekolah') }}" required>
                    </div>

                    <!-- SEKSI PILIHAN JURUSAN & GELOMBANG -->
                    <div class="form-section-title" style="grid-column: span 2; margin-top: 25px;">Pilihan Jurusan & Gelombang Pendaftaran</div>
                    
                    <div class="form-group">
                        <label>Pilihan Kompetensi Keahlian (Jurusan 1) <span>*</span></label>
                        <div class="radio-group-container">
                            <label class="selection-option"><input type="radio" name="jurusan_pilihan_1" value="PPLG" required>PPLG</label>
                            <label class="selection-option"><input type="radio" name="jurusan_pilihan_1" value="BCF" required>BCF</label>
                            <label class="selection-option"><input type="radio" name="jurusan_pilihan_1" value="MPLB" required>MPLB</label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Pilihan Kompetensi Keahlian (Jurusan 2) <span>*</span></label>
                        <div class="radio-group-container">
                            <label class="selection-option"><input type="radio" name="jurusan_pilihan_2" value="PPLG" required>PPLG</label>
                            <label class="selection-option"><input type="radio" name="jurusan_pilihan_2" value="BCF" required>BCF</label>
                            <label class="selection-option"><input type="radio" name="jurusan_pilihan_2" value="MPLB" required>MPLB</label>
                        </div>
                    </div>

                    <!-- DROPDOWN GELOMBANG PENDAFTARAN -->
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Pilih Gelombang Pendaftaran <span>*</span></label>
                        <select id="gelombang_pendaftaran" name="gelombang" class="form-control" onchange="toggleGelombang(this.value)" required>
                            <option value="" disabled selected>Pilih Gelombang Pendaftaran</option>
                            <option value="Gelombang 1" {{ old('gelombang_pendaftaran') == 'Gelombang 1' ? 'selected' : '' }}>Gelombang 1 (Januari - Maret 2026)</option>
                            <option value="Gelombang 2" {{ old('gelombang_pendaftaran') == 'Gelombang 2' ? 'selected' : '' }}>Gelombang 2 (April - Juli 2026)</option>
                        </select>
                    </div>

                    <!-- METODE PEMBAYARAN (OTOMATIS MUNCUL JIKA MEMILIH GELOMBANG 2) -->
                    <div class="form-group conditional-box" id="metode-pembayaran-container" style="grid-column: span 2;">
                        <label id="labelMetodePembayaran">Pilih Metode Pembayaran Pendaftaran (Rp 20.000) <span>*</span></label>
                        <select id="metode_pembayaran" name="metode_pembayaran" class="form-control" onchange="toggleMetodePembayaran(this.value)">
                            <option value="" disabled selected>Pilih Metode Pembayaran</option>
                            <option value="langsung" {{ old('metode_pembayaran') == 'langsung' ? 'selected' : '' }}>Bayar Langsung di Sekolah (Cash)</option>
                            <option value="transfer" {{ old('metode_pembayaran') == 'transfer' ? 'selected' : '' }}>Transfer Bank (Via TF)</option>
                        </select>
                    </div>

                    <!-- KOTAK INFORMASI REKENING (MUNCUL JIKA PILIH TRANSFER) -->
                    <div class="form-group conditional-box" id="info-rekening-box" style="grid-column: span 2;">
                        <div style="background-color: #e6f4f0; border: 1px solid #02403f; padding: 15px 20px; border-radius: 8px; font-size: 13px; color: #02403f;">
                            <strong><i class="fa-solid fa-building-columns"></i> Informasi Rekening Pembayaran:</strong><br>
                            Bank: <strong id="txtRekBank">Bank Jateng</strong><br>
                            No. Rekening: <strong id="txtRekNomor">3-012-34567-8</strong><br>
                            Atas Nama: <strong id="txtRekAtasNama">SMK Ma'arif Walisongo Kajoran</strong><br>
                            <small id="txtRekCatatan" style="color: #64748b; margin-top: 5px; display: block;">*Silakan lakukan transfer sesuai biaya pendaftaran, lalu simpan bukti transfer untuk diunggah di halaman berikutnya.</small>
                        </div>
                    </div>

                </div> 
                
                <div class="action-buttons">
                    <a href="{{ url('/daftar') }}" class="btn-back">← Kembali</a>
                    <button type="submit" class="btn-next">Selanjutnya →</button>
                </div>
            </form>
        </main>
    </div>

    <script>
        function toggleKphCard(isSelectIya) {
            const cardSelectionBox = document.getElementById('kph-card-selection');
            const checkboxes = document.querySelectorAll('input[name="jenis_kartu[]"]');
            
            if (isSelectIya) {
                cardSelectionBox.style.display = 'block';
                localStorage.setItem('penerima_kps_status', 'ya');
            } else {
                cardSelectionBox.style.display = 'none';
                checkboxes.forEach(cb => {
                    cb.checked = false;
                });
                localStorage.setItem('penerima_kps_status', 'tidak');
            }
        }

        function toggleGelombang(val) {
            const containerPembayaran = document.getElementById('metode-pembayaran-container');
            const selectPembayaran = document.getElementById('metode_pembayaran');
            const infoRekeningBox = document.getElementById('info-rekening-box');

            localStorage.setItem('gelombang_pendaftaran', val);

            if (val === 'Gelombang 2') {
                containerPembayaran.style.display = 'block';
                selectPembayaran.setAttribute('required', 'required');
            } else {
                containerPembayaran.style.display = 'none';
                infoRekeningBox.style.display = 'none';
                selectPembayaran.removeAttribute('required');
                selectPembayaran.value = "";
                localStorage.setItem('metode_pembayaran', 'gratis');
            }
        }

        function toggleMetodePembayaran(val) {
            const infoRekening = document.getElementById('info-rekening-box');
            
            if (val === 'transfer') {
                infoRekening.style.display = 'block';
                localStorage.setItem('metode_pembayaran', 'transfer');
            } else {
                infoRekening.style.display = 'none';
                localStorage.setItem('metode_pembayaran', 'langsung');
            }
        }
    </script>

    <script>
        const baseAPI = 'https://www.emsifa.com/api-wilayah-indonesia/api';

        const selectProvinsi = document.getElementById('provinsi');
        const selectKabupaten = document.getElementById('kabupaten');
        const selectKecamatan = document.getElementById('kecamatan');
        const selectKelurahan = document.getElementById('kelurahan');

        fetch(baseAPI + '/provinces.json')
            .then(response => response.json())
            .then(provinces => {
                provinces.forEach(prov => {
                    let option = document.createElement('option');
                    option.value = prov.id;
                    option.textContent = prov.name;
                    selectProvinsi.appendChild(option);
                });
                loadSavedWilayah();
            })
            .catch(err => console.error('Gagal memuat provinsi:', err));

        selectProvinsi.addEventListener('change', function() {
            loadKabupaten(this.value);
        });

        function loadKabupaten(provId, selectedKabId = null) {
            selectKabupaten.innerHTML = '<option value="">Pilih Kabupaten</option>';
            selectKecamatan.innerHTML = '<option value="">Pilih Kecamatan</option>';
            selectKelurahan.innerHTML = '<option value="">Pilih Kelurahan/Desa</option>';

            selectKecamatan.disabled = true;
            selectKelurahan.disabled = true;

            if (provId) {
                fetch(baseAPI + '/regencies/' + provId + '.json')
                    .then(response => response.json())
                    .then(regencies => {
                        regencies.forEach(kab => {
                            let option = document.createElement('option');
                            option.value = kab.id;
                            option.textContent = kab.name;
                            selectKabupaten.appendChild(option);
                        });
                        selectKabupaten.disabled = false;
                        if (selectedKabId) {
                            selectKabupaten.value = selectedKabId;
                        }
                    });
            } else {
                selectKabupaten.disabled = true;
            }
        }

        selectKabupaten.addEventListener('change', function() {
            loadKecamatan(this.value);
        });

        function loadKecamatan(kabId, selectedKecId = null) {
            selectKecamatan.innerHTML = '<option value="">Pilih Kecamatan</option>';
            selectKelurahan.innerHTML = '<option value="">Pilih Kelurahan/Desa</option>';

            selectKecamatan.disabled = true;
            selectKelurahan.disabled = true;

            if (kabId) {
                fetch(baseAPI + '/districts/' + kabId + '.json')
                    .then(response => response.json())
                    .then(districts => {
                        districts.forEach(kec => {
                            let option = document.createElement('option');
                            option.value = kec.id;
                            option.textContent = kec.name;
                            selectKecamatan.appendChild(option);
                        });
                        selectKecamatan.disabled = false;
                        if (selectedKecId) {
                            selectKecamatan.value = selectedKecId;
                        }
                    });
            } else {
                selectKecamatan.disabled = true;
            }
        }

        selectKecamatan.addEventListener('change', function() {
            loadKelurahan(this.value);
        });

        function loadKelurahan(kecId, selectedKelId = null) {
            selectKelurahan.innerHTML = '<option value="">Pilih Kelurahan/Desa</option>';

            if (kecId) {
                fetch(baseAPI + '/villages/' + kecId + '.json')
                    .then(response => response.json())
                    .then(villages => {
                        villages.forEach(des => {
                            let option = document.createElement('option');
                            option.value = des.id;
                            option.textContent = des.name;
                            selectKelurahan.appendChild(option);
                        });
                        selectKelurahan.disabled = false;
                        if (selectedKelId) {
                            selectKelurahan.value = selectedKelId;
                        }
                    });
            } else {
                selectKelurahan.disabled = true;
            }
        }
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const jurusan1Radios = document.querySelectorAll('input[name="jurusan_1"]');
            const jurusan2Radios = document.querySelectorAll('input[name="jurusan_2"]');

            function sinkronisasiJurusan() {
                let valueTerpilihJ1 = "";
                jurusan1Radios.forEach(radio => {
                    if (radio.checked) {
                        valueTerpilihJ1 = radio.value;
                    }
                });
                jurusan2Radios.forEach(radio => {
                    if (radio.value === valueTerpilihJ1) {
                        radio.disabled = true;
                        if (radio.checked) radio.checked = false;
                    } else {
                        radio.disabled = false;
                    }
                });
            }
            
            jurusan1Radios.forEach(radio => radio.addEventListener('change', sinkronisasiJurusan));
            jurusan2Radios.forEach(radio => radio.addEventListener('change', sinkronisasiJurusan));
        });
    </script>

    <!-- SKRIP PENYIMPANAN DAN SINKRONISASI KE ADMIN (LOCALSTORAGE) -->
    <script>
        function loadSavedWilayah() {
            const savedData = JSON.parse(localStorage.getItem('data_pendaftaran'));
            if (!savedData) return;

            if (savedData.provinsi) {
                selectProvinsi.value = savedData.provinsi;
                loadKabupaten(savedData.provinsi, savedData.kabupaten);
            }
            if (savedData.kabupaten) {
                loadKecamatan(savedData.kabupaten, savedData.kecamatan);
            }
            if (savedData.kecamatan) {
                loadKelurahan(savedData.kecamatan, savedData.kelurahan);
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
            const form = document.getElementById('formPendaftaran');
            
            // AUTO-FILL DATA SAAT HALAMAN DIBUKA
            const savedData = JSON.parse(localStorage.getItem('data_pendaftaran'));
            if (savedData) {
                if (savedData.nama) document.getElementById('input_nama_lengkap_calon_siswa').value = savedData.nama;
                if (savedData.asalSekolah) document.getElementById('input_asal_sekolah').value = savedData.asalSekolah;
                if (savedData.nisn) document.getElementById('input_NISN').value = savedData.nisn;
                if (savedData.hp) document.getElementById('input_nomor_hp_siswa').value = savedData.hp;
                if (savedData.tempatLahir) document.getElementById('input_tempat_lahir').value = savedData.tempatLahir;
                if (savedData.tinggi) document.getElementById('input_tinggi').value = savedData.tinggi;
                if (savedData.berat) document.getElementById('input_berat').value = savedData.berat;
                if (savedData.tglLahir) document.getElementById('input_tanggal_lahir').value = savedData.tglLahir;
                if (savedData.jumlahSaudara) document.getElementById('input_jumlah_saudara').value = savedData.jumlahSaudara;
                if (savedData.agama) document.getElementById('input_agama').value = savedData.agama;

                if (savedData.jenisKelamin) {
                    const el = document.querySelector(`input[name="jenis_kelamin"][value="${savedData.jenisKelamin}"]`);
                    if (el) el.checked = true;
                }
                if (savedData.kebutuhanKhusus) {
                    const el = document.querySelector(`input[name="kebutuhan_khusus"][value="${savedData.kebutuhanKhusus}"]`);
                    if (el) el.checked = true;
                }
                if (savedData.penerimaKps) {
                    const el = document.querySelector(`input[name="penerima_kps"][value="${savedData.penerimaKps}"]`);
                    if (el) {
                        el.checked = true;
                        toggleKphCard(savedData.penerimaKps === 'ya');
                    }
                }
                if (savedData.jenisKartu && Array.isArray(savedData.jenisKartu)) {
                    savedData.jenisKartu.forEach(val => {
                        const cb = document.querySelector(`input[name="jenis_kartu[]"][value="${val}"]`);
                        if (cb) cb.checked = true;
                    });
                }

                // Data Ayah
                if (savedData.namaAyah) document.getElementById('input_nama_ayah').value = savedData.namaAyah;
                if (savedData.pendidikanAyah) document.getElementById('pendidikan_ayah').value = savedData.pendidikanAyah;
                if (savedData.pekerjaanAyah) document.getElementById('input_pekerjaan_ayah').value = savedData.pekerjaanAyah;
                if (savedData.tahunAyah) document.getElementById('input_tahun_lahir_ayah').value = savedData.tahunAyah;
                if (savedData.penghasilanAyah) document.getElementById('penghasilan_ayah_select').value = savedData.penghasilanAyah;
                if (savedData.hpAyah) document.getElementById('input_nomor_telepon_ayah').value = savedData.hpAyah;
                if (savedData.khususAyah) {
                    const el = document.querySelector(`input[name="kebutuhan_khusus_ayah"][value="${savedData.khususAyah}"]`);
                    if (el) el.checked = true;
                }

                // Data Ibu
                if (savedData.namaIbu) document.getElementById('input_nama_ibu').value = savedData.namaIbu;
                if (savedData.pendidikanIbu) document.getElementById('pendidikan_ibu').value = savedData.pendidikanIbu;
                if (savedData.pekerjaanIbu) document.getElementById('input_pekerjaan_ibu').value = savedData.pekerjaanIbu;
                if (savedData.tahunIbu) document.getElementById('input_tahun_lahir_ibu').value = savedData.tahunIbu;
                if (savedData.penghasilanIbu) document.getElementById('penghasilan_ibu_select').value = savedData.penghasilanIbu;
                if (savedData.hpIbu) document.getElementById('input_nomor_telepon_ibu').value = savedData.hpIbu;
                if (savedData.khususIbu) {
                    const el = document.querySelector(`input[name="kebutuhan_khusus_ibu"][value="${savedData.khususIbu}"]`);
                    if (el) el.checked = true;
                }

                // Data Wali
                if (savedData.namaWali) document.getElementById('input_nama_wali').value = savedData.namaWali;
                if (savedData.pendidikanWali) document.getElementById('pendidikan_wali').value = savedData.pendidikanWali;
                if (savedData.pekerjaanWali) document.getElementById('input_pekerjaan_wali').value = savedData.pekerjaanWali;
                if (savedData.penghasilanWali) document.getElementById('penghasilan_wali_select').value = savedData.penghasilanWali;
                if (savedData.hpWali) document.getElementById('input_nomor_telepon_wali').value = savedData.hpWali;

                // Tempat Tinggal
                if (savedData.alamatLengkap) document.getElementById('input_alamat_lengkap').value = savedData.alamatLengkap;
                if (savedData.rt) document.getElementById('input_rt').value = savedData.rt;
                if (savedData.rw) document.getElementById('input_rw').value = savedData.rw;
                if (savedData.jenisTinggal) document.getElementById('jenis_tinggal').value = savedData.jenisTinggal;
                if (savedData.transportasi) document.getElementById('input_alat_transportasi').value = savedData.transportasi;
                if (savedData.kodePos) document.getElementById('input_kode_pos').value = savedData.kodePos;
                if (savedData.jarakSekolah) document.getElementById('input_jarak_kesekolah').value = savedData.jarakSekolah;

                // Jurusan & Gelombang
                if (savedData.jurusan1) {
                    const el = document.querySelector(`input[name="jurusan_1"][value="${savedData.jurusan1}"]`);
                    if (el) el.checked = true;
                }
                if (savedData.jurusan2) {
                    const el = document.querySelector(`input[name="jurusan_2"][value="${savedData.jurusan2}"]`);
                    if (el) el.checked = true;
                }
                if (savedData.gelombang) {
                    document.getElementById('gelombang_pendaftaran').value = savedData.gelombang;
                    toggleGelombang(savedData.gelombang);
                }
                if (savedData.metodePembayaran) {
                    document.getElementById('metode_pembayaran').value = savedData.metodePembayaran;
                    toggleMetodePembayaran(savedData.metodePembayaran);
                }
            }

            // SIMPAN DATA DAN SINKRONKAN KE ADMIN SAAT SUBMIT
            form.addEventListener('submit', function (e) {
                const getRadioVal = (name) => {
                    const el = document.querySelector(`input[name="${name}"]:checked`);
                    return el ? el.value : '';
                };

                const getCheckboxVals = (name) => {
                    const els = document.querySelectorAll(`input[name="${name}"]:checked`);
                    return Array.from(els).map(cb => cb.value);
                };

                const getSelectText = (id) => {
                    const sel = document.getElementById(id);
                    return (sel && sel.selectedIndex >= 0 && sel.options[sel.selectedIndex].value !== "") 
                        ? sel.options[sel.selectedIndex].text 
                        : '';
                };

                const now = new Date();
                const tglDaftarFormat = `${now.getDate().toString().padStart(2, '0')} ${now.toLocaleString('id-ID', { month: 'short' })} ${now.getFullYear()}`;
                
                let existingData = JSON.parse(localStorage.getItem('data_pendaftaran')) || {};
                const studentId = existingData.id || "SISWA-" + Date.now();
                const noRegNumber = existingData.noReg || "SPMB-2027-" + Math.floor(1000 + Math.random() * 9000);

                const dataPendaftaran = {
                    id: studentId,
                    noReg: noRegNumber,
                    tglDaftar: existingData.tglDaftar || tglDaftarFormat,
                    status: existingData.status || "Aktif",

                    nama: document.getElementById('input_nama_lengkap_calon_siswa').value,
                    asalSekolah: document.getElementById('input_asal_sekolah').value,
                    sekolah: document.getElementById('input_asal_sekolah').value,
                    nisn: document.getElementById('input_NISN').value,
                    hp: document.getElementById('input_nomor_hp_siswa').value,
                    tempatLahir: document.getElementById('input_tempat_lahir').value,
                    tinggi: document.getElementById('input_tinggi').value,
                    berat: document.getElementById('input_berat').value,
                    fisik: `${document.getElementById('input_tinggi').value} cm / ${document.getElementById('input_berat').value} kg`,
                    tglLahir: document.getElementById('input_tanggal_lahir').value,
                    jumlahSaudara: document.getElementById('input_jumlah_saudara').value,
                    saudara: document.getElementById('input_jumlah_saudara').value,
                    jenisKelamin: getRadioVal('jenis_kelamin'),
                    jk: getRadioVal('jenis_kelamin') === 'L' ? 'Laki-laki' : 'Perempuan',
                    kebutuhanKhusus: getRadioVal('kebutuhan_khusus'),
                    agama: document.getElementById('input_agama').value,
                    penerimaKps: getRadioVal('penerima_kps'),
                    jenisKartu: getCheckboxVals('jenis_kartu[]'),
                    kpsKip: getRadioVal('penerima_kps') === 'ya' ? `Ya (${getCheckboxVals('jenis_kartu[]').join(', ') || 'Ada'})` : 'Tidak',

                    // Data Ayah
                    namaAyah: document.getElementById('input_nama_ayah').value,
                    pendidikanAyah: getSelectText('pendidikan_ayah'),
                    pekerjaanAyah: document.getElementById('input_pekerjaan_ayah').value,
                    tahunAyah: document.getElementById('input_tahun_lahir_ayah').value,
                    penghasilanAyah: getSelectText('penghasilan_ayah_select'),
                    hpAyah: document.getElementById('input_nomor_telepon_ayah').value,
                    khususAyah: getRadioVal('kebutuhan_khusus_ayah'),

                    // Data Ibu
                    namaIbu: document.getElementById('input_nama_ibu').value,
                    pendidikanIbu: getSelectText('pendidikan_ibu'),
                    pekerjaanIbu: document.getElementById('input_pekerjaan_ibu').value,
                    tahunIbu: document.getElementById('input_tahun_lahir_ibu').value,
                    penghasilanIbu: getSelectText('penghasilan_ibu_select'),
                    hpIbu: document.getElementById('input_nomor_telepon_ibu').value,
                    khususIbu: getRadioVal('kebutuhan_khusus_ibu'),

                    // Data Wali
                    namaWali: document.getElementById('input_nama_wali').value || "-",
                    pendidikanWali: getSelectText('pendidikan_wali') || "-",
                    pekerjaanWali: document.getElementById('input_pekerjaan_wali').value || "-",
                    penghasilanWali: getSelectText('penghasilan_wali_select') || "-",
                    hpWali: document.getElementById('input_nomor_telepon_wali').value || "-",

                    // Data Tempat Tinggal
                    provinsi: getSelectText('provinsi'),
                    kabupaten: getSelectText('kabupaten'),
                    kecamatan: getSelectText('kecamatan'),
                    kelurahan: getSelectText('kelurahan'),
                    alamatLengkap: document.getElementById('input_alamat_lengkap').value,
                    rt: document.getElementById('input_rt').value,
                    rw: document.getElementById('input_rw').value,
                    rtRw: `RT ${document.getElementById('input_rt').value} / RW ${document.getElementById('input_rw').value}`,
                    jenisTinggal: document.getElementById('jenis_tinggal').value,
                    transportasi: document.getElementById('input_alat_transportasi').value,
                    kodePos: document.getElementById('input_kode_pos').value,
                    jarakSekolah: document.getElementById('input_jarak_kesekolah').value,

                    // Jurusan & Gelombang
                    jurusan1: getRadioVal('jurusan_1'),
                    jurusan2: getRadioVal('jurusan_2'),
                    gelombang: document.getElementById('gelombang_pendaftaran').value,
                    metodePembayaran: document.getElementById('metode_pembayaran').value
                };

                // 1. Simpan untuk panel siswa
                localStorage.setItem('data_pendaftaran', JSON.stringify(dataPendaftaran));

                // 2. Sinkronkan langsung ke daftar pendaftar Admin (list_pendaftar)
                let listPendaftarAdmin = JSON.parse(localStorage.getItem('list_pendaftar')) || [];
                const existingIndex = listPendaftarAdmin.findIndex(item => String(item.id) === String(dataPendaftaran.id));

                if (existingIndex !== -1) {
                    listPendaftarAdmin[existingIndex] = dataPendaftaran;
                } else {
                    listPendaftarAdmin.unshift(dataPendaftaran);
                }

                localStorage.setItem('list_pendaftar', JSON.stringify(listPendaftarAdmin));
            });
        });
    </script>

<script>
/* ==========================================================================
   SINKRONISASI DENGAN CMS (localStorage: landing_page_config)
   ========================================================================== */
(function () {
    let config;
    try { config = JSON.parse(localStorage.getItem('landing_page_config')); } catch (e) { config = null; }
    if (!config) return;

    function setSrc(id, value) { if (!value) return; const el = document.getElementById(id); if (el) el.src = value; }
    function setText(id, value) { if (!value) return; const el = document.getElementById(id); if (el) el.textContent = value; }

    // --- Logo Navbar (satu sumber dari config.home) ---
    if (config.home && config.home.navbarLogos) {
        setSrc('navLogoSekolah', config.home.navbarLogos.logoSekolah);
        setSrc('navLogoSmkHebat', config.home.navbarLogos.logoSmkHebat);
        setSrc('navLogoVokasi', config.home.navbarLogos.logoVokasi);
        setSrc('navLogoAkreditasi', config.home.navbarLogos.logoAkreditasi);
    }

    if (!config.pendaftaran || !config.pendaftaran.formulir) return;
    const f = config.pendaftaran.formulir;

    setText('formulirJudul', f.judul);
    setText('formulirDesc', f.desc);
    setText('txtRekBank', f.rekBank);
    setText('txtRekNomor', f.rekNomor);
    setText('txtRekAtasNama', f.rekAtasNama);
    setText('txtRekCatatan', f.rekCatatan);

    if (f.biayaGelombang2) {
        const lbl = document.getElementById('labelMetodePembayaran');
        if (lbl) {
            const star = lbl.querySelector('span');
            lbl.innerHTML = `Pilih Metode Pembayaran Pendaftaran (${f.biayaGelombang2}) `;
            if (star) lbl.appendChild(star);
        }
    }
})();
</script>
</body>
</html>