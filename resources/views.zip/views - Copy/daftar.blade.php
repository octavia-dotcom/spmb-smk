<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Akun - SMK Ma'arif Walisongo Kajoran</title>
<link rel="icon" type="image/png" href="{{ asset('img/logo.smk.png') }}">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ==========================================================================
           1. RESET & GLOBAL STYLES
           ========================================================================== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
          font-family: 'Poppins', sans-serif;
          background-color: #02403f; 
          color: #1e293b;
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          justify-content: flex-start; 
          gap: 35px; /* 💡 Ini yang otomatis memberi jarak renggang seragam antara navbar dan form buat akun */
          padding: 5px 5px 40px 5px; /* Memberi jarak aman di bawah layar laptop */
         }
        .register-container {
            width: 100%;
            max-width: 1000px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 30px;
            padding: 40px 50px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }

          /* ==========================================================================
           2. NAVBAR ATAS (KOTAK PUTIH KAPSUL MELAYANG)
           ========================================================================== */
        .navbar {
         background-color: #ffffff;
         box-shadow: 0 10px 30px rgba(0,0,0,0.15); 
         position: sticky;
         top: 20px; 
         z-index: 1000;
         width: 94%; 
         margin: 20px auto 0 auto; 
         border-radius: 15px; 
         padding: 5px 25px; 
         }
        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 15px;
        }

        /* Pembungkus Semua Logo di Sebelah Kiri */
        .logo-group {
            display: flex;
            align-items: center;
            gap: 15px; /* Mengatur jarak antar logo */
        }

        /* Tinggi Logo Diperkecil agar Muat Sempurna di Kapsul Navigasi */
        .logo-sekolah { height: 45px; width: auto; }
        .logo-smkhebat { height: 45px; width: auto; }
        .logo-vokasi { height: 45px; width: auto; }
        .logo-akreditasi-nav { height: 45px; width: auto; }

        /* Menu Navigasi Tengah */
        .nav-menu {
            display: flex;
            align-items: center;
        }

        .nav-menu a {
            text-decoration: none;
            color: #475569;
            margin: 0 15px;
            font-weight: 600;
            font-size: 15px;
            transition: color 0.3s;
        }

        .nav-menu a:hover, .nav-menu a.active {
            color: #047857; /* Hijau saat aktif / disorot */
        }

        /* Tombol Log In di Kanan Navbar */
        .btn-cta {
            background-color: #064e3b;
            color: white;
            text-decoration: none;
            padding: 10px 35px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 15px;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
        }

        .btn-cta:hover {
            background-color: #047857;
        }

        /* ==========================================================================
           3. HERO SECTION & BACKGROUND
           ========================================================================== */
        .hero {
            background-color: #003a3b;
            background-image: linear-gradient(to right, rgba(0, 58, 59, 1) 30%, rgba(0, 58, 59, 0.8) 50%, rgba(0, 58, 59, 0.15) 100%), url('img/sekolah.png');
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            color: white;
            padding: 40px 0 140px 0;
            position: relative;
            overflow: hidden;
            margin-top: -110px; /* Menarik background naik melewati bagian bawah nav */
            padding-top: 150px; /* Mendorong teks turun agar tidak tertutup nav */
        }

        .hero-container {
            display: grid;
            grid-template-columns: 1.2fr 0.8fr;
            gap: 40px;
            align-items: center;
            position: relative;
            z-index: 5;
        }

        .sub-title {
            color: #6ee7b7;
            font-size: 15px;
            font-weight: 700px;
            letter-spacing: 3px;
            margin-bottom: 10px;
            margin-top: 20x;
        }

        .hero-text h1 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 48px;
            font-weight: 800;
            line-height: 1.2;
        }

        .highlight {
            color: #5eead4;
        }

        .desc {
            color: #e2e8f0;
            margin-top: 20px;
            line-height: 1.6;
            max-width: 550px;
            font-size: 15px;
        }

        /* Pembungkus Kotak Badge Mini */
        .badge-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-top: 30px;
            max-width: 850px;
        }

        .badge-card {
            display: flex;
            align-items: center;
            background: rgba(0, 43, 44, 0.65); /* Hijau tua transparan biar tulisan putih tetep keliatan di kanan */
            backdrop-filter: blur(8px);       /* Efek blur halus di background gambar sekolah */
            border: 1px solid rgba(255, 255, 255, 0.15);
            padding: 14px 20px;
            border-radius: 12px;
            color: #ffffff;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .badge-card:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
        }

        .badge-icon-box {
            width: 42px;
            height: 42px;
            margin-right: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .badge-icon-box img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        
        .badge-card:not(:last-child) .badge-icon-box img {
            filter: brightness(0) invert(1); 
        }

        /* Kelompok Tombol Hero */
        .btn-group {
            margin-top: 40px;
            display: flex;
            gap: 15px;
            position: relative;
            z-index: 10;
        }

        .btn-primary {
            background-color: white;
            color: #022c22;
            text-decoration: none;
            padding: 15px 30px;
            border-radius: 12px;
            font-weight: 700;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
            transition: 0.3s;
        }

        .btn-primary:hover {
            background-color: #e2e8f0;
        }

        .btn-secondary {
            border: 1px solid rgba(255,255,255,0.4);
            color: white;
            text-decoration: none;
            padding: 15px 25px;
            border-radius: 12px;
            font-weight: 600;
            transition: 0.3s;
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        /* Area Foto Kanan Hero */
        .hero-image {
            display: flex;
            justify-content: center;
            position: relative;
        }

        .image-box {
            width: 100%;
            max-width: 340px;
            height: auto;
            padding: 0px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            margin-top: 32px;
        }

        .foto-hero {
            width: 100%;
            height: 100%;
            object-fit: contain;
            border-radius: 14px;
        }

        /* ==========================================================================
           3. HEADER & STEPPER PROGRESS
           ========================================================================== */
        .register-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px dashed #e2e8f0;
            padding-bottom: 25px;
            margin-bottom: 30px;
        }
        .header-title-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .icon-add-user {
         width: 50px;          /* Atur lebar wadah ikon */
         height: 50px;         /* Atur tinggi wadah ikon */
         background-color: #e6f4f0; /* Contoh: Memberi warna latar belakang mini */
         border-radius: 50%;   /* Membuat wadahnya bulat sempurna */
         display: flex;
         align-items: center;
         justify-content: center;
        }
        .icon-add-user img {
           width: 50px !important;    /* 💡 Paksa lebar gambar */
           height: 50px !important;   /* 💡 Paksa tinggi gambar (wajib sama dengan width biar kotak/bulat sempurna) */
           flex-shrink: 0;            /* 🎯 Kunci utama agar gambar TIDAK BISA gepeng/menciut */
           object-fit: contain;       /* 💡 Memastikan isi gambar tetap proporsional di tengah */
         }
        .header-text h1 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 18px;
            font-weight: 800;
            color: #02403f;
        }
        .header-text p {
            font-size: 10px;
            color: #64748b;
        }

        /* Steps Progress Bar */
        .stepper-groups {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .step-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .step-number {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 700;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .step-item.active .step-number {
            background-color: #02403f;
            color: #ffffff;
        }
        .step-item.inactive .step-number {
            border: 1px solid #cbd5e1;
            color: #94a3b8;
            background: #ffffff;
        }
        .step-text {
            font-size: 11px;
            font-weight: 600;
            color: #475569;
        }
        .step-item.inactive .step-text {
            color: #94a3b8;
        }
        .step-line {
            width: 30px;
            height: 1px;
            background-color: #cbd5e1;
        }

        /* ==========================================================================
           4. FORM INPUTS & LAYOUT
           ========================================================================== */
        .form-section-title {
            font-size: 14px;
            font-weight: 700;
            color: #007a53;
            margin-bottom: 20px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            column-gap: 40px;
 row-gap: 20px;
            margin-bottom: 35px;
        }
        .form-control {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .form-control label {
            font-size: 12px;
            font-weight: 600;
            color: #334155;
        }
        .form-control input {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            outline: none;
            transition: border-color 0.2s;
        }
        .form-control input:focus {
            border-color: #007a53;
        }

        /* ==========================================================================
           5. BUTTONS ACTION
           ========================================================================== */
        .action-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }
        .btn-back {
            border: 1px solid #02403f;
            background: transparent;
            color: #02403f;
            padding: 10px 25px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background 0.2s;
        }
        .btn-back:hover {
            background-color: #f0f7f4;
        }
        .btn-next {
            background-color: #02403f;
            border: none;
            color: #ffffff;
            padding: 11px 50px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background 0.2s;
            text-decoration: none !important;
        }
        .btn-next:hover {
            background-color: #012b2a;
        }

        /* ==========================================================================
           6. FOOTER INFORMASI
           ========================================================================== */
           .register-footer {
            width: 100%;
            max-width: 1000px;
            margin: 30px auto 0 auto;
            display: grid;
            grid-template-columns: 1.2fr 0.9fr 0.9fr 1fr;
            gap: 25px;
            color: #ffffff;
            opacity: 0.9;
            font-size: 11px;
            padding-top: 10px;
        }
        
        .footer-info-item {
            display: flex;
            align-items: flex-start; /* Tetap rata atas */
            gap: 12px;
            border-left: 2px solid #EBE0D0; 
            padding-left: 15px;             
        }

        .footer-icon {
            width: 35px !important;    
            height: 35px !important;   
            flex-shrink: 0;            
            object-fit: contain;       
            margin-top: 0 !important; /* Paksa nockan jarak atas ikon */
        }

        /* 🎯 BERSIHKAN DAN PAKSA TULISAN NAIK LEWAT SINI */
        .footer-info-item > div {
            margin-top: -3px !important; /* Menaikkan semua box teks di semua kolom */
            line-height: 1.3 !important; /* Merapatkan jarak teks baris 1 dan 2 agar ikut terangkat */
        }

        .quote-text {
            font-style: italic;
        }
        .footer-info-item > div {
            margin-top: -15px; /* 💡 Kalau kurang naik, ganti angkanya jadi -5px atau -6px. Atur sesukamu! */
        }
        /* RESPONSIVE LAYOUT UNTUK HP */
        @media (max-width: 768px) {
            .register-header { flex-direction: column; gap: 20px; align-items: flex-start; }
            .form-grid { grid-template-columns: 1fr; }
            .register-footer { grid-template-columns: 1fr; gap: 20px; }
        }
    </style>
</head>
<body>
     <header class="navbar">
        <div class="nav-container">
            <div class="logo-group">
                <img src="img/logo.smk.png" alt="Logo SMK Ma'arif" class="logo-sekolah">
                <img src="img/logo-smk-hebat.png" alt="Logo SMK Bisa Hebat" class="logo-smkhebat">
                <img src="img/logo-smk-vokasi.png" alt="Logo SMK Vokasi" class="logo-vokasi">
                <img src="img/akreditasi.png" alt="Akreditasi A" class="logo-akreditasi-nav">
            </div>

            <nav class="nav-menu">
                <a href="{{ url('/home') }}">Beranda</a>
                <a href="{{ url('/daftar') }}" class="active">Pendaftaran</a>
                <a href="{{ url('/jurusan') }}">Jurusan</a>
                <a href="{{ url('/informasi') }}">Informasi</a>
                <a href="{{ url('/kontak') }}">Kontak</a>
            </nav>
            
            <a href="{{ url('/login') }}" class="btn-cta">Log in</a>
        </div>
    </header>

    <div class="register-container">
        
        <header class="register-header">
            <div class="header-title-group">
                <div class="icon-add-user img">
                  <img src="img/orangtambah.png" alt="daftar akun">
                </div>
                <div class="header-text">
                    <h1>Pendaftaran Akun</h1>
                    <p>Langkah pertama untuk bergabung bersama SMK Ma'arif Walisongo Kajoran</p>
                </div>
            </div>

            <div class="stepper-groups">
                <a href="{{ url('/daftar') }}" style="text-decoration: none;"></a>
                <div class="step-item active">
                    <div class="step-number">1</div>
                    <span class="step-text">Buat Akun</span>
                </div>
                <div class="step-line"></div>
                <a href="{{ url('/formulir') }}" style="text-decoration: none;"></a>
                <div class="step-item inactive">
                    <div class="step-number">2</div>
                    <span class="step-text">Isi Formulir</span>
                </div>
                <div class="step-line"></div>
                <a href="{{ url('/unggah-berkas') }}" style="text-decoration: none;"></a>
                <div class="step-item inactive">
                    <div class="step-number">3</div>
                    <span class="step-text">Unggah Berkas</span>
                </div>
            </div>
        </header>

        <main>
            <div class="form-section-title">Data Akun</div>
            
            <form action="{{ route('register.proses') }}" method="POST">
    @csrf
    <div class="form-grid">
        <div class="form-control">
            <label for="nama">Nama Lengkap</label>
            <input type="text" id="name" name="name" placeholder="Masukkan nama lengkap" required>
        </div>
        
        <div class="form-control">
            <label for="whatsapp">No. HP / WhatsApp</label>
            <input type="tel" id="whatsapp" name="no_hp" placeholder="Masukkan no. HP aktif" required>
        </div>
        
        <div class="form-control">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Masukkan alamat email" required>
        </div>
        
        <div class="form-control">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Masukkan password akun" required>
        </div>
    </div>
    
    <div class="action-buttons">
        <a href="{{ url('/home') }}" class="btn-back">← Kembali</a>
        <!-- Tombol diubah menjadi button type="submit" agar bisa mengirim data -->
        <button type="submit" class="btn-next" style="border: none; cursor: pointer;">Selanjutnya →</button>
    </div>
</form>
        </main>
    </div>

    <footer class="register-footer">
        <div class="footer-info-item">
            <img src="img/lokasi.png" alt="Icon" class="footer-icon">
            <div>
                <strong>SMK Ma'arif Walisongo Kajoran</strong><br>
                Jl. KH. Ridwan, Sidowangi, Kajoran, Kab. Magelang, Jawa Tengah 56163.
            </div>
        </div>
        
        <div class="footer-info-item">
            <img src="img/kontak.png" alt="Icon" class="footer-icon">
            <div>
                <strong>Hubungi Kami</strong><br>
                (0293) 3195678<br>
                www.ppdb.smkmaarifwalisongokajoran.sch.id
            </div>
        </div>
        
        <div class="footer-info-item">
            <img src="img/jam.png" alt="Icon" class="footer-icon">
            <div>
                <strong>Jam Operasional</strong><br>
                Senin - Jumat<br>
                07.00 - 12.00
            </div>
        </div>
        
        <div class="footer-info-item">
            <div class="quote-text">
                "Menyiapkan generasi islami, kompeten dan berakhlakul karimah."
            </div>
        </div>
    </footer>