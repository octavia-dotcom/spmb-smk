<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPMB SMK Ma'arif Walisongo Kajoran</title>
<link rel="icon" type="image/png" href="{{ asset('img/logo.smk.png') }}">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        /* ==========================================================================
           1. RESET & DASAR
           ========================================================================== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8fafc;
            color: #334155;
        }

        .container {
             width: 100%;
             max-width: 100%; 
             padding: 0 5%;  
             margin: 0;       
        }

        /* ==========================================================================
           2. NAVBAR ATAS (KOTAK PUTIH KAPSUL MELAYANG)
           ========================================================================== */
        .navbar {
            background-color: #ffffff;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15); /* Bayangan lebih tegas agar melayang */
            position: sticky;
            top: 20px; /* Jarak melayang dari atas layar */
            z-index: 1000;
            width: 94%; /* Lebar proporsional kotak putih */
            margin: 20px auto 0 auto; /* Menengahkan posisi navbar */
            border-radius: 15px; /* üëà KUNCI UTAMA: Membuat bentuk kapsul melengkung penuh */
            padding: 5px 25px; /* Ruang dalam kotak navbar */
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 15px;
        }

        /* Pembungkus Semua Logo di Sebelah Kiri */
        .logo-group {
            display: flex;
            align-items: center;
            gap: 12px; /* Mengatur jarak antar logo */
        }

        /* Tinggi Logo Diperkecil agar Muat Sempurna di Kapsul Navigasi */
        .logo-sekolah { height: 45px; width: auto; }
        .logo-smkhebat { height: 45px; width: auto; }
        .logo-vokasi { height: 45px; width: auto; }
        .logo-akreditasi-nav { height: 45px; width: auto; }

        /* Menu Navigasi Tengah */
        .nav-menu {
            display: flex;
            align-items: center;
        }

        .nav-menu a {
            text-decoration: none;
            color: #475569;
            margin: 0 15px;
            font-weight: 600;
            font-size: 15px;
            transition: color 0.3s;
        }

        .nav-menu a:hover, .nav-menu a.active {
            color: #047857; /* Hijau saat aktif / disorot */
        }

        /* Tombol Log In di Kanan Navbar */
        .btn-cta {
            background-color: #064e3b;
            color: white;
            text-decoration: none;
            padding: 10px 35px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 15px;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
        }

        .btn-cta:hover {
            background-color: #047857;
        }

        /* ==========================================================================
           3. HERO SECTION & BACKGROUND
           ========================================================================== */
        .hero {
            background-color: #003a3b;
            background-image: linear-gradient(to right, rgba(0, 58, 59, 1) 30%, rgba(0, 58, 59, 0.8) 50%, rgba(0, 58, 59, 0.15) 100%), url('img/sekolah.png');
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            color: white;
            padding: 40px 0 140px 0;
            position: relative;
            overflow: hidden;
            margin-top: -110px; /* Menarik background naik melewati bagian bawah nav */
            padding-top: 150px; /* Mendorong teks turun agar tidak tertutup nav */
        }

        .hero-container {
            display: grid;
            grid-template-columns: 1.2fr 0.8fr;
            gap: 40px;
            align-items: center;
            position: relative;
            z-index: 5;
        }

        .sub-title {
            color: #6ee7b7;
            font-size: 15px;
            font-weight: 700px;
            letter-spacing: 3px;
            margin-bottom: 10px;
            margin-top: 20px;
        }

        .hero-text h1 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 48px;
            font-weight: 800;
            line-height: 1.2;
        }

        .highlight {
            color: #5eead4;
        }

        .desc {
            color: #e2e8f0;
            margin-top: 20px;
            line-height: 1.6;
            max-width: 550px;
            font-size: 15px;
        }

        /* Pembungkus Kotak Badge Mini */
        .badge-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-top: 30px;
            max-width: 850px;
        }

        .badge-card {
            display: flex;
            align-items: center;
            background: rgba(0, 43, 44, 0.65); /* Hijau tua transparan biar tulisan putih tetep keliatan di kanan */
            backdrop-filter: blur(8px);       /* Efek blur halus di background gambar sekolah */
            border: 1px solid rgba(255, 255, 255, 0.15);
            padding: 14px 20px;
            border-radius: 12px;
            color: #ffffff;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .badge-card:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
        }

        .badge-icon-box {
            width: 42px;
            height: 42px;
            margin-right: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .badge-icon-box img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        
        .badge-card:not(:last-child) 
        .badge-icon-box img {
            filter: brightness(0) invert(1); 
        }

        /* Kelompok Tombol Hero */
        .btn-group {
            margin-top: 40px;
            display: flex;
            gap: 15px;
            position: relative;
            z-index: 10;
        }

        .btn-primary {
            background-color: white;
            color: #022c22;
            text-decoration: none;
            padding: 15px 30px;
            border-radius: 12px;
            font-weight: 700;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
            transition: 0.3s;
        }

        .btn-primary:hover {
            background-color: #e2e8f0;
        }

        .btn-secondary {
            border: 1px solid rgba(255,255,255,0.4);
            color: white;
            text-decoration: none;
            padding: 15px 25px;
            border-radius: 12px;
            font-weight: 600;
            transition: 0.3s;
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        /* Area Foto Kanan Hero */
        .hero-image {
            display: flex;
            justify-content: center;
            position: relative;
        }

        .image-box {
            width: 100%;
            max-width: 340px;
            height: auto;
            padding: 0px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            margin-top: 32px;
        }

        .foto-hero {
            width: 100%;
            height: 100%;
            object-fit: contain;
            border-radius: 14px;
        }
        
        /* ==========================================================================
           4. DESAIN TIMELINE ALUR PPDB ONLINE
           ========================================================================== */
        .ppdb-flow-container {
            padding: 0 3%;
            margin-top: -80px;
            position: relative;
            z-index: 10;
        }

        /* Kotak Utama Pembungkus Alur */
        .ppdb-flow-card {
            display: flex;
            width: 100%;
            max-width: 14500px;
            margin: 0 auto;
            height: 260px;
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            overflow: hidden;
            border: 1px solid #e2e8f0;
        }

        /* Bagian Kiri (Kotak Hijau Tua) */
        .ppdb-sidebar-green {
            width: 280px;
            background: linear-gradient(135deg, #003a3b 0%, #046e56 100%);
            padding: 35px 25px;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            flex-shrink: 0;
        }

        .ppdb-sidebar-green h3 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 12px;
            line-height: 1.3;
        }

        .ppdb-sidebar-green p {
            font-size: 13px;
            color: #ccfbf1;
            line-height: 1.5;
            margin-bottom: 25px;
        }

        /* Bagian Kanan (Alur Langkah-Langkah) */
        .ppdb-flow-steps {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 0 20px;
            position: relative;
        }

        /* Garis Putus-putus Horizontal di Belakang Bulatan */
        .ppdb-step-line {
            position: absolute;
            top: 35%; /* Posisi pas di tengah-tengah bulatan */
            left: 8%;
            width: 84%;
            height: 2px;
            border-top: 2px dashed #cbd5e1;
            z-index: 1;
        }

        /* Item Tiap Langkah */
        .flow-step-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            position: relative;
            z-index: 2; /* Biar berada di atas garis putus-putus */
            flex: 1;
        }

        /* Bulatan Wadah Ikon */
        .flow-icon-circle {
            width: 95px;
            height: 95px;
            background: #ffffff;
            border-radius: 50%;
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
            border: 1px solid #f1f5f9;
        }

        .flow-icon-circle img {
            width: 80%; /* Ukuran ikon di dalam bulatan */
            height: 80%;
            object-fit: contain;
        }

        .flow-step-num {
            font-size: 12px;
            font-weight: 700;
            color: #94a3b8;
            margin-bottom: 3px;
        }

        .flow-step-title {
            font-size: 14px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 5px;
        }

        .flow-step-desc {
            font-size: 11px;
            color: #64748b;
            max-width: 120px;
            line-height: 1.4;
        }

        /* Responsive: Mengubah Alur Jadi Vertikal Jika di Layar HP */
        @media (max-width: 992px) {
            .ppdb-flow-card { 
                flex-direction: column; 
                height: auto; }
            .ppdb-sidebar-green { 
                width: 100%; 
                text-align: center; 
                align-items: center; 
            }
            .ppdb-flow-steps { 
                flex-direction: column; 
                padding: 40px 0; 
                gap: 30px; 
            }
            .ppdb-step-line { 
                display: none; 
            } /* Sembunyikan garis horizontal di HP */
        }

        /* ==========================================================================
           4B. BARU: KOTAK INFO SEKOLAH (VISI-MISI & JADWAL-SYARAT)
           ========================================================================== */
        .info-school-section {
            padding: 40px 0 0 0;
        }

        .info-school-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            width: 100%;            /* Mengurangi lebar dari 100% menjadi 85% agar lebih ramping */
            max-width: 1500px;     /* Membatasi lebar maksimal kotak agar tidak terlalu melar di layar besar */
            margin: 40px auto 100 auto; /* 'auto' di kanan & kiri otomatis menggeser kotak ke POSISI TENGAH */
            padding: 0 5%;
            box-sizing: border-box;
        }

        .info-box-card {
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.04);
            border: 1px solid #e2e8f0;
            padding: 35px;
            display: flex;
            flex-direction: column;
            justify-content: flex start;
        }

        .info-box-title {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 22px;
            font-weight: 700;
            color: #003a3b;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-bottom: 2px solid #f1f5f9;
            padding-bottom: 12px;
        }

        .info-box-title img {
            width: 80px;
            height:80px;
            object-fit: contain;
        }
        .info-box-title span {
            background: #ccfbf1;
            color: #047857;
            padding: 5px 12px;
            border-radius: 8px;
            font-size: 14px;
        }

        /* Konten Visi Misi */
        .visi-wrapper {
            background: #f8fafc;
            border-left: 4px solid #047857;
            padding: 15px 20px;
            border-radius: 0 12px 12px 0;
            margin-bottom: 25px;
        }

        .visi-label {
            font-size: 12px;
            font-weight: 700;
            color: #047857;
            letter-spacing: 1px;
            margin-bottom: 4px;
        }

        .visi-text {
            font-size: 15px;
            font-weight: 600;
            color: #0f172a;
            font-style: italic;
            line-height: 1.5;
        }

        .misi-list {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .misi-list li {
            font-size: 13px;
            line-height: 1.6;
            color: #475569;
            position: relative;
            padding-left: 25px;
        }

        .misi-list li::before {
            content: "✓";
            position: absolute;
            left: 0;
            top: 0;
            color: #047857;
            font-weight: 900;
            font-size: 15px;
        }

        /* Konten Jadwal & Syarat */
        .jadwal-timeline {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 30px;
        }

        .jadwal-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(to right, #f8fafc, #ffffff);
            padding: 14px 20px;
            border-radius: 12px;
            border: 1px solid #f1f5f9;
        }

        .jadwal-gel {
            font-size: 14px;
            font-weight: 700;
            color: #0f172a;
        }

        .jadwal-tgl {
            font-size: 13px;
            font-weight: 600;
            color: #047857;
            background: #e6f4ea;
            padding: 4px 12px;
            border-radius: 30px;
        }

        .syarat-badge-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .syarat-badge {
            background: #f1f5f9;
            color: #334155;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 600;
            border: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
        }

        .syarat-badge:hover {
            background: #003a3b;
            color: #ffffff;
            border-color: #003a3b;
        }
        /* Grid khusus penampung 8 Logo Mitra Usaha */
        .unit-usaha-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr); /* 4 kolom menyamping */
            gap: 12px;
            margin-top: 10px;
        }

        .unit-usaha-item {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 8px;
            height: 70px; /* Mengunci tinggi kotak logo agar seragam */
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }

        .unit-usaha-item:hover {
            border-color: #047857;
            background: #ffffff;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }

        .unit-usaha-item img {
            max-width: 150%;
            max-height: 150%;
            object-fit: contain;
        }

        /* Penyesuaian ke HP untuk Grid Info Baru */
        @media (max-width: 992px) {
            .info-school-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
        }

        /* ==========================================================================
           5. RESPONSIVE MOBILE LAYOUT (Aturan khusus tampilan HP)
           ========================================================================== */
        @media (max-width: 768px) {
            .navbar {
                width: 90%;
                padding: 5px 15px;
            }
            .nav-menu {
                display: none; /* Menyembunyikan menu link di HP */
            }
            .hero-container {
                grid-template-columns: 1fr;
            }
            .ppdb-timeline {
                grid-template-columns: 1fr;
                margin-top: 20px;
            }
            .hero-text h1 {
                font-size: 32px;
            }
            .badge-container {
                grid-template-columns: repeat(2, 1fr);
            }
        } 
        
        /* ==========================================================================
           6. DESAIN SEKSI FITUR UNGGULAN (BAWAH)
           ========================================================================== */
        .fitur-section {
            margin-top: -30px;
            padding: 30px 3% 60px 3%;
            text-align: center;
        }

        /* Judul Fitur Unggulan dengan Garis di Kiri-Kanan */
        .fitur-title-wrapper {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 40px;
            margin-top: 50px;
        }

        .fitur-line {
            flex: 1;
            max-width: 150px;
            height: 2px;
            background: linear-gradient(to right, transparent, #047857, transparent);
        }

        .fitur-title-wrapper h2 {
            color: #003a3b;
            font-size: 24px;
            font-weight: 700;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* Grid Pembagi 6 Kotak */
        .fitur-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Kotak Fitur Individual */
        .fitur-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            text-align: left;
            box-shadow: 0 4px 15px rgba(0,0,0,0.01);
            transition: all 0.3s ease;
            width: 220px;
        }

        .fitur-card:hover {
            transform: translateY(-3px);
            border-color: #047857;
            box-shadow: 0 6px 20px rgba(4, 120, 87, 0.08);
        }

        /* Lingkaran / Kotak Icon */
        .fitur-icon-box {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .fitur-icon-box img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        /* Teks di Dalam Kotak */
        .fitur-info h4 {
            font-size: 13px;
            color: #0f172a;
            font-weight: 700;
            margin-bottom: 3px;
        }

        .fitur-info p {
            font-size: 11px;
            color: #64748b;
            line-height: 1.4;
        }

        /* Biar rapi kalau dibuka di HP */
        @media (max-width: 1024px) {
            .fitur-grid { grid-template-columns: repeat(3, 1fr); } /* Jadi 3 kolom di tablet */
        }
        @media (max-width: 640px) {
            .fitur-grid { grid-template-columns: 1fr; } /* Jadi 1 kolom memanjang di HP */
        }
        
        /* ==========================================================================
           7.DESAIN SEKSI KONTAK, SOSMED & MAPS (FOOTER)
           ========================================================================== */
        .footer-section {
            background-color: #003a3b; /* Warna hijau tua khas sekolah */
            color: #ffffff;
            padding: 60px 5% 30px 5%;
            margin-top: 60px;
            font-family: sans-serif;
        }

        .footer-container {
            display: flex;
            flex-wrap: wrap;
            gap: 40px;
            justify-content: space-between;
            max-width: 1250px;
            margin: 0 auto;
        }

        /* Kolom Info Sekolah & Sosmed */
        .footer-info-col {
            flex: 1;
            min-width: 300px;
        }

        .footer-info-col h3 {
            font-size: 22px;
            color: #5eead4; /* Warna hijau mint */
            margin-bottom: 15px;
            font-weight: 700;
        }

        .footer-info-col p {
            font-size: 14px;
            color: #e2e8f0;
            line-height: 1.6;
            margin-bottom: 25px;
        }

        /* Barisan Ikon Sosial Media */
        .sosmed-wrapper {
            display: flex;
            gap: 15px;
            margin-top: 15px;
        }

        .sosmed-wrapper img{
            width: 50px;
            height:50px;
            object-fit: contain;
        }

        .sosmed-link {
            width: 45px;         /* Ukuran bulatan wadah logo */
            height: 45px;
            background-color: rgba(255, 255, 255, 0.1); /* Background transparan tipis */
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        /* Efek sedikit membesar saat logo ditunjuk kursor */
        .sosmed-link:hover {
            transform: scale(1.1);
            background-color: rgba(255, 255, 255, 0.2); 
        }

        /* KUNCI: Mengatur ukuran gambar logo di dalam bulatan */
        .sosmed-link img {
            width: 35px;        /* Atur ukuran lebar logo di sini */
            height: 35px;       /* Atur ukuran tinggi logo di sini */
            object-fit: contain;/* Biar gambarnya proporsional & ga gepeng */
        }

        /* Efek warna ketika ikon sosmed di-hover/disentuh kursor */
        .sosmed-link.instagram:hover { background-color: #e1306c; }
        .sosmed-link.youtube:hover { background-color: #ff0000; }
        .sosmed-link.facebook:hover { background-color: #1877f2; }
        .sosmed-link.whatsaap:hover { background-color: #25D366; }

        /* Kolom Google Maps */
        .footer-maps-col {
            flex: 1;
            min-width: 300px;
            max-width: 600px;
        }

        .footer-maps-col h3 {
            font-size: 18px;
            color: #5eead4;
            margin-bottom: 15px;
        }

        .map-responsive {
            overflow: hidden;
            border-radius: 12px;
            border: 2px solid rgba(255, 255, 255, 0.1);
            height: 250px;
        }

        .map-responsive iframe {
            width: 100%;
            height: 100%;
            border: 0;
        }

        /* Hak Cipta di paling bawah */
        .footer-copyright { 
            text-align: center;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 13px;
            color: #94a3b8;
        }

        /* Responsif untuk HP */
        @media (max-width: 768px) {
            .footer-container { flex-direction: column; }
            .footer-maps-col { max-width: 100%; }
        }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="nav-container">
            <div class="logo-group">
                <img src="img/logo.smk.png" alt="Logo SMK Ma'arif" class="logo-sekolah" id="navLogoSekolah">
                <img src="img/logo-smk-hebat.png" alt="Logo SMK Bisa Hebat" class="logo-smkhebat" id="navLogoSmkHebat">
                <img src="img/logo-smk-vokasi.png" alt="Logo SMK Vokasi" class="logo-vokasi" id="navLogoVokasi">
                <img src="img/akreditasi.png" alt="Akreditasi A" class="logo-akreditasi-nav" id="navLogoAkreditasi">
            </div>

            <nav class="nav-menu">
                <a href="{{ url('/home') }}" class="active">Beranda</a>
                <a href="{{ url('/daftar') }}">Pendaftaran</a>
                <a href="{{ url('/jurusan') }}">Jurusan</a>
                <a href="{{ url('/informasi') }}">Informasi</a>
                <a href="{{ url('/kontak') }}">Kontak</a>
            </nav>
            
            <a href="{{ url('/login') }}" class="btn-cta">Log in</a>
        </div>
    </header>

    <section class="hero" id="heroSection">
        <div class="container hero-container">
            <div class="hero-text">
                <p class="sub-title" id="heroSubTitle">SISTEM PENERIMAAN MURID BARU</p>
                <h1><span id="heroTitleLine1">SMK MA'ARIF</span> <br><span class="highlight" id="heroTitleLine2">WALISONGO KAJORAN</span></h1>
                <p class="desc" id="heroDesc">Membentuk generasi unggul, berkarakter, berkompeten dan berdaya saing global melalui pendidikan vokasi berkualitas dan berlandaskan nilai-nilai Islam.</p>
                
                <div class="badge-container" id="heroBadges">
                    <div class="badge-card">
                        <div class="badge-icon-box">
                            <img src="img/toga.png" alt="Sekolah Islam Berprestasi">
                        </div>
                        <span>Sekolah Islam Berprestasi</span>
                    </div>

                    <div class="badge-card">
                        <div class="badge-icon-box">
                            <img src="img/settings.png" alt="Kompeten di Bidangnya">
                        </div>
                        <span>Kompeten di Bidangnya</span>
                    </div>

                    <div class="badge-card">
                        <div class="badge-icon-box">
                            <img src="img/orang3.png" alt="Siap Kerja & Wirausaha">
                        </div>
                        <span>Siap Kerja & Wirausaha</span>
                    </div>

                    <div class="badge-card">
                        <div class="badge-icon-box">
                            <img src="img/globe.png" alt="Berwawasan Global">
                        </div>
                        <span>Berwawasan Global</span>
                     </div>
                </div>

                <div class="btn-group">
                    <a href="{{ url('/daftar') }}" class="btn-primary" id="heroBtn1">Daftar Sekarang  →</a>
                    <a href="{{ url('/jurusan') }}" class="btn-secondary" id="heroBtn2">Lihat Jurusan </a>
                </div>
            </div>

            <div class="hero-image">
                <div class="image-box">
                    <img src="img/spmb.jpeg" alt="Siswa Berjas Hijau" class="foto-hero" id="heroFotoSiswa">
                </div>
            </div>
        </div>
    </section>

    <section class="ppdb-flow-container">
        <div class="ppdb-flow-card">
            
            <div class="ppdb-sidebar-green">
                <h3 id="ppdbTitle">SISTEM SPMB ONLINE</h3>
                <p id="ppdbDesc">"Solusi praktis pendaftaran bagi calon siswa baru yang terkendala jarak dan waktu. Nikmati kemudahan pengisian formulir hingga unggah berkas cukup lewat smartphone Anda."</p>
            </div>

            <div class="ppdb-flow-steps" id="ppdbSteps">
                <div class="ppdb-step-line"></div>
                
                <div class="flow-step-item">
                    <div class="flow-icon-circle">
                        <img src="img/orangtambah.png" alt="Buat Akun"> </div>
                    <div class="flow-step-num">LANGKAH 1</div>
                    <div class="flow-step-title">Buat Akun</div>
                    <div class="flow-step-desc">Log in dan lengkapi data diri anda untuk membuat akun pendaftaran.</div>
                </div>

                <div class="flow-step-item">
                    <div class="flow-icon-circle">
                        <img src="img/note.png" alt="Isi Formulir"> </div>
                    <div class="flow-step-num">LANGKAH 2</div>
                    <div class="flow-step-title">Isi Formulir</div>
                    <div class="flow-step-desc">Isi formulir biodata siswa secara lengkap dan benar.</div>
                </div>

                <div class="flow-step-item">
                    <div class="flow-icon-circle">
                        <img src="img/i_cloud.png" alt="Unggah Berkas"> </div>
                    <div class="flow-step-num">LANGKAH 3</div>
                    <div class="flow-step-title">Unggah Berkas</div>
                    <div class="flow-step-desc">Upload berkas administrasi seperti KK dan Akta Kelahiran.</div>
                </div>

                <div class="flow-step-item">
                    <div class="flow-icon-circle">
                        <img src="img/centang.png" alt="Verifikasi"> </div>
                    <div class="flow-step-num">LANGKAH 4</div>
                    <div class="flow-step-title">Verifikasi Data</div>
                    <div class="flow-step-desc">Tunggu proses pengecekan berkas oleh panitia sekolah.</div>
                </div>

                <div class="flow-step-item">
                    <div class="flow-icon-circle">
                        <img src="img/badge_reward.png" alt="Pengumuman"> </div>
                    <div class="flow-step-num">LANGKAH 5</div>
                    <div class="flow-step-title">Pengumuman</div>
                    <div class="flow-step-desc">Lihat hasil seleksi penerimaan langsung di dashboard.</div>
                </div>

            </div>
        </div>
    </section>

    <section class="info-school-section">
        <div class="info-school-grid">
            
            <div class="info-box-card">
                <div class="info-box-title">
                    <img src="img/visi & misi.png" alt="ikon-visi-misi">
                    Visi & Misi Sekolah
                </div>
                <div class="visi-wrapper">
                    <div class="visi-label">VISI</div>
                    <div class="visi-text" id="visiText">“Sekolah Kejuruan yang unggul, Bertaqwa Berkarakter, Terampil, dan Professional”</div>
                </div>
                <div class="visi-label" style="margin-bottom: 10px;">MISI</div>
                <ul class="misi-list" id="misiList">
                    <li>Menanamkan nilai-nilai Islam Ahlussunah Wal Jama’ah nilai-nilai kebangsaan dengan berkarakter tinggi dan berakhlak mulia.</li>
                    <li>Meningkatkan mutu penyelenggaraan pendidikan sehingga menghasilkan lulusan yang memiliki kompetensi yang kompetitif.</li>
                    <li>Meningkatkan keterampilan di bidang kejuruan.</li>
                    <li>Memiliki kompetensi dan membangun jiwa wirausaha yang handal.</li>
                    <li>Melaksanakan sistem pendidikan berbasis teknologi informasi dan komunikasi.</li>
                </ul>
            </div>

            <div class="info-box-card">
                <div class="info-box-title">
                    <img src="img/informasi.png">
                        Informasi Pendaftaran
                </div>
                
                <div class="visi-label" style="margin-bottom: 12px;">JADWAL GELOMBANG</div>
                <div class="jadwal-timeline" id="jadwalTimeline">
                    <div class="jadwal-item">
                        <span class="jadwal-gel">Gelombang 1</span>
                        <span class="jadwal-tgl">Januari - Maret 2026</span>
                    </div>
                    <div class="jadwal-item">
                        <span class="jadwal-gel">Gelombang 2</span>
                        <span class="jadwal-tgl">April - Juli 2026</span>
                    </div>
                </div>

             <div class="visi-label" style="margin-bottom: 10px;">Syarat Pendaftaran</div>
                <ul class="misi-list" id="syaratList">
                    <li>Mengisi Formulir Pendaftaran</li>
                    <li>Foto Copy Kartu Keluarga</li>
                    <li>Pas foto ukuran 3x4 [4 lembar] </li>
                    <li>Pas foto ukuran 4x6 [2 lembar]</li>
                    <li>Biaya pendaftaran Rp.20.000 [Khusus gel. II]</li>
                    <li>Foto Copy KIP,PKH,KPS,KIS, bagi yang memiliki</li>
                    <li>Foto copy KTP kedua orang tua</li>
                    <li>Foto copy Akta Kelahiran</li>
                </ul>
            </div>

            <div class="info-box-card">
                <div class="info-box-title">
                    <img src="img/unit_usaha.png" alt="Ikon Mitra Usaha">
                     Unit Usaha Sekolah
                </div>
                
                <div class="unit-usaha-grid" id="unitUsahaGrid">
                    <div class="unit-usaha-item">
                        <img src="img/NANO.png" alt="Logo Usaha 1">
                    </div>
                    <div class="unit-usaha-item">
                        <img src="img/ANANTARA.png" alt="Logo Usaha 2">
                    </div>
                    <div class="unit-usaha-item">
                        <img src="img/RADIKSA.png" alt="Logo Usaha 3">
                    </div>
                    <div class="unit-usaha-item">
                        <img src="img/NJE.png" alt="Logo Usaha 4">
                    </div>
                    <div class="unit-usaha-item">
                        <img src="img/TEFA.png" alt="Logo Usaha 5">
                    </div>
                    <div class="unit-usaha-item">
                        <img src="img/wandeQTA.png" alt="Logo Usaha 6">
                    </div>
                    <div class="unit-usaha-item">
                        <img src="img/mwtv.png" alt="Logo Usaha 7">
                </div>
            </div>
            <div class="visi-label" style="margin-top: 25px; margin-bottom: 12px;">KEUNGGULAN & PRAKTIK KERJA</div>
                <ul class="misi-list" id="keunggulanList">
                    <li><strong>Praktik Langsung:</strong> Siswa dilatih langsung mengelola bisnis riil di seluruh jaringan Unit Usaha Sekolah.</li>
                    <li><strong>Kesiapan Kerja:</strong> Lulusan memiliki pengalaman kerja nyata yang diakui oleh dunia usaha dan industri.</li>
                    <li><strong>Peluang Wirausaha:</strong> Inkubator bisnis sekolah siap mencetak lulusan menjadi pengusaha muda mandiri.</li>
                </ul>
        </div>
    </section>

    <section class="container fitur-section">
        <div class="fitur-title-wrapper">
            <div class="fitur-line"></div>
            <h2>● Fitur Utama ●</h2>
            <div class="fitur-line"></div>
        </div>

        <div class="fitur-grid" id="fiturGrid">
            
            <div class="fitur-card">
                <div class="fitur-icon-box">
                    <img src="img/pc.png" alt="PPDB Online"> </div>
                <div class="fitur-info">
                    <h4>PPDB Online</h4>
                    <p>Pendaftaran online mudah, cepat dan terpercaya.</p>
                </div>
            </div>

            <div class="fitur-card">
                <div class="fitur-icon-box">
                    <img src="img/ikon.png" alt="Informasi Lengkap"> </div>
                <div class="fitur-info">
                    <h4>Informasi Lengkap</h4>
                    <p>Informasi jurusan, biaya, jadwal dan berita terbaru.</p>
                </div>
            </div>

            <div class="fitur-card">
                <div class="fitur-icon-box">
                    <img src="img/note.png" alt="Cek Status"> </div>
                <div class="fitur-info">
                    <h4>Cek Status</h4>
                    <p>Pantau status pendaftaran secara real-time.</p>
                </div>
            </div>

            <div class="fitur-card">
                <div class="fitur-icon-box">
                    <img src="img/toa.png" alt="Pengumuman"> </div>
                <div class="fitur-info">
                    <h4>Pengumuman</h4>
                    <p>Informasi hasil seleksi dapat diakses dengan mudah.</p>
                </div>
            </div>

            <div class="fitur-card">
                <div class="fitur-icon-box">
                    <img src="img/telepon.png" alt="Kontak Cepat"> </div>
                <div class="fitur-info">
                    <h4>Kontak Cepat</h4>
                    <p>Hubungi kami untuk informasi lebih lanjut.</p>
                </div>
            </div>

        </div>
    </section>

    <footer class="footer-section">
        <div class="footer-container">
            
            <div class="footer-info-col">
                <h3>SMK Ma'arif Walisongo Kajoran</h3>
                <p>Jl.KH.Ridwan Sidowangi Kajoran, Magelang, Jawa Tengah 56163.<br>Mencetak generasi yang Smart, Religious, dan Professional.</p>
                
               <div class="sosmed-wrapper">
        <a href="https://www.instagram.com/officialsmkmw9?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" class="sosmed-link" target="_blank">
        <img src="img/instagram.png" alt="Instagram">
    </a>
        <a href="https://www.tiktok.com/@officialsmkmw9?is_from_webapp=1&sender_device=pc" class="sosmed-link" target="_blank">
        <img src="img/tiktok.png" alt="TikTok">
    </a>
        <a href="https://www.youtube.com/@officialsmkmaarifwalisongo1198" class="sosmed-link" target="_blank">
        <img src="img/youtube.png" alt="YouTube">
    </a>
        <a href="https://www.facebook.com/pages/SMKS%20MA%60ARIF%20WALISONGO%20KAJORAN/1631217363784893/#" class="sosmed-link" target="_blank">
        <img src="img/fecebook.png" alt="Facebook">
    </a>
    <a href="https://wa.me/02933195678" class="sosmed-link" target="_blank">
        <img src="img/whatsaap.png" alt="whatsaap">
    </a>
</div>
            </div>

            <div class="footer-maps-col">
                <h3>Lokasi Sekolah</h3>
                <div class="map-responsive">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3955.820849844561!2d110.09843167476278!3d-7.485024792527013!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a9079770d82a3%3A0xbc67a5962af92284!2sSMK%20Ma'arif%20Walisongo%20Kajoran!5e0!3m2!1sid!2sid!4v1782578283304!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe></div>
            </div>

        </div>

        <div class="footer-copyright">
            <p>© 2026 SMK Ma'arif Walisongo Kajoran Tim TEFA. All Rights Reserved.</p>
        </div>
    </footer>
    <script>
/* ==========================================================================
   SINKRONISASI DENGAN CMS (DENGAN SAFE FALLBACK)
   ========================================================================== */
(function () {
    let config;
    try { config = JSON.parse(localStorage.getItem('landing_page_config')); } catch (e) { config = null; }
    if (!config || !config.home) return; 
    const h = config.home;

    function setSrc(id, value) {
        if (!value) return;
        const el = document.getElementById(id);
        if (el) el.src = value;
    }
    
    function setText(id, value) {
        if (value === undefined || value === null || value === '') return;
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    }

    if (h.navbarLogos) {
        setSrc('navLogoSekolah', h.navbarLogos.logoSekolah);
        setSrc('navLogoSmkHebat', h.navbarLogos.logoSmkHebat);
        setSrc('navLogoVokasi', h.navbarLogos.logoVokasi);
        setSrc('navLogoAkreditasi', h.navbarLogos.logoAkreditasi);
    }

    if (h.hero) {
        const hr = h.hero;
        setText('heroSubTitle', hr.sub);
        setText('heroTitleLine1', hr.title1);
        setText('heroTitleLine2', hr.title2);
        setText('heroDesc', hr.desc);

        const btn1 = document.getElementById('heroBtn1');
        if (btn1) {
            // Menggunakan teks dari CMS, atau fallback ke "Daftar Sekarang →" jika kosong
            btn1.textContent = hr.btn1Text ? hr.btn1Text : "Daftar Sekarang  →";
            if (hr.btn1Link) btn1.href = hr.btn1Link;
        }
        
        const btn2 = document.getElementById('heroBtn2');
        if (btn2) {
            btn2.textContent = hr.btn2Text ? hr.btn2Text : "Lihat Jurusan";
            if (hr.btn2Link) btn2.href = hr.btn2Link;
        }
        
        if (hr.bgImage) {
            const heroSection = document.getElementById('heroSection');
            if (heroSection) heroSection.style.backgroundImage =
                `linear-gradient(to right, rgba(0, 58, 59, 1) 30%, rgba(0, 58, 59, 0.8) 50%, rgba(0, 58, 59, 0.15) 100%), url('${hr.bgImage}')`;
        }
        setSrc('heroFotoSiswa', hr.fotoSiswa);
    }

    if (Array.isArray(h.badges) && h.badges.length) {
        const wrap = document.getElementById('heroBadges');
        if (wrap) {
            // Hanya update teks label tiap badge, ikon gambar (.png) bawaan halaman TIDAK diganti/dirender ulang
            const cards = wrap.querySelectorAll('.badge-card');
            h.badges.forEach((b, i) => {
                const card = cards[i];
                if (!card) return; // jumlah badge tetap mengikuti struktur asli halaman
                const span = card.querySelector('span');
                if (span && b.label) span.textContent = b.label;
            });
        }
    }

    if (h.ppdb) {
        setText('ppdbTitle', h.ppdb.title);
        setText('ppdbDesc', h.ppdb.desc);
        if (Array.isArray(h.ppdb.steps) && h.ppdb.steps.length) {
            const container = document.getElementById('ppdbSteps');
            if (container) {
                // Hanya update judul & deskripsi tiap langkah, ikon gambar (.png) bawaan halaman TIDAK diganti/dirender ulang
                const items = container.querySelectorAll('.flow-step-item');
                h.ppdb.steps.forEach((s, i) => {
                    const item = items[i];
                    if (!item) return; // jumlah langkah tetap mengikuti struktur asli halaman
                    const titleEl = item.querySelector('.flow-step-title');
                    const descEl = item.querySelector('.flow-step-desc');
                    if (titleEl && s.title) titleEl.textContent = s.title;
                    if (descEl && s.desc) descEl.textContent = s.desc;
                });
            }
        }
    }

    if (h.visi) {
        setText('visiText', h.visi.text ? `“${h.visi.text}”` : undefined);
        if (Array.isArray(h.visi.misi) && h.visi.misi.length) {
            const list = document.getElementById('misiList');
            if (list) list.innerHTML = h.visi.misi.map(m => `<li>${m.text || ''}</li>`).join('');
        }
    }

    if (h.pendaftaranInfo) {
        if (Array.isArray(h.pendaftaranInfo.jadwal) && h.pendaftaranInfo.jadwal.length) {
            const el = document.getElementById('jadwalTimeline');
            if (el) el.innerHTML = h.pendaftaranInfo.jadwal.map(j => `
                <div class="jadwal-item">
                    <span class="jadwal-gel">${j.gelombang || ''}</span>
                    <span class="jadwal-tgl">${j.tanggal || ''}</span>
                </div>`).join('');
        }
        if (Array.isArray(h.pendaftaranInfo.syarat) && h.pendaftaranInfo.syarat.length) {
            const el = document.getElementById('syaratList');
            if (el) el.innerHTML = h.pendaftaranInfo.syarat.map(s => `<li>${s.text || ''}</li>`).join('');
        }
    }

    // Perbaikan Unit Usaha agar gambar tidak hilang total jika path gagal
    if (h.unitUsaha && Array.isArray(h.unitUsaha.logos) && h.unitUsaha.logos.length > 0) {
        const grid = document.getElementById('unitUsahaGrid');
        if (grid) {
            grid.innerHTML = h.unitUsaha.logos.map(u => `
                <div class="unit-usaha-item">
                    <img src="${u.logo || ''}" alt="${u.nama || 'Logo Usaha'}" onerror="this.src='img/NANO.png';">
                </div>`).join('');
        }
    }

    if (h.unitUsaha && Array.isArray(h.unitUsaha.keunggulan) && h.unitUsaha.keunggulan.length > 0) {
        const list = document.getElementById('keunggulanList');
        if (list) list.innerHTML = h.unitUsaha.keunggulan.map(k => `<li><strong>${k.label || ''}:</strong> ${k.desc || ''}</li>`).join('');
    }

    if (Array.isArray(h.fitur) && h.fitur.length) {
        const grid = document.getElementById('fiturGrid');
        if (grid) {
            // Hanya update judul & deskripsi tiap kartu fitur, ikon gambar (.png) bawaan halaman TIDAK diganti/dirender ulang
            const cards = grid.querySelectorAll('.fitur-card');
            h.fitur.forEach((f, i) => {
                const card = cards[i];
                if (!card) return; // jumlah kartu tetap mengikuti struktur asli halaman
                const titleEl = card.querySelector('h4');
                const descEl = card.querySelector('p');
                if (titleEl && f.title) titleEl.textContent = f.title;
                if (descEl && f.desc) descEl.textContent = f.desc;
            });
        }
    }
})();
</script>
</body>
</html>